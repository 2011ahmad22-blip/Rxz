import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, Shield, MessageSquare, Star, Gift,
  Terminal, GitMerge, Settings, Bot, Zap, ChevronLeft, X, Ticket, BookOpen,
} from "lucide-react";
import { cn } from "@/lib/utils";

const navGroups = [
  {
    label: "عام",
    items: [
      { path: "/", label: "الرئيسية", icon: LayoutDashboard },
      { path: "/commands", label: "مرجع الأوامر", icon: BookOpen },
    ],
  },
  {
    label: "الإدارة",
    items: [
      { path: "/moderation", label: "الإشراف", icon: Shield },
      { path: "/protection", label: "الحماية", icon: Zap },
    ],
  },
  {
    label: "المميزات",
    items: [
      { path: "/welcome", label: "الترحيب والوداع", icon: MessageSquare },
      { path: "/levels", label: "المستويات والـ XP", icon: Star },
      { path: "/giveaways", label: "السحوبات", icon: Gift },
      { path: "/tickets", label: "نظام التذاكر", icon: Ticket },
    ],
  },
  {
    label: "التخصيص",
    items: [
      { path: "/custom-commands", label: "الأوامر المخصصة", icon: Terminal },
      { path: "/aliases", label: "الاختصارات", icon: GitMerge },
      { path: "/settings", label: "الإعدادات", icon: Settings },
    ],
  },
];

type Props = { totalWarnings?: number; totalMuted?: number; onClose?: () => void; };

export function Sidebar({ totalWarnings, totalMuted, onClose }: Props) {
  const [location] = useLocation();

  return (
    <aside className="sidebar-gradient w-64 flex-shrink-0 border-r border-border flex flex-col h-screen">
      {/* Header */}
      <div className="p-5 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center shadow-lg shadow-purple-500/25 flex-shrink-0">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div className="absolute -bottom-0.5 -left-0.5 w-3 h-3 rounded-full bg-green-500 border-2 border-[hsl(222,47%,7%)] animate-pulse" />
            </div>
            <div>
              <h1 className="font-bold text-white text-sm leading-tight">RXZ System Bot</h1>
              <p className="text-xs text-purple-400/80 font-medium">الاحترافية v2.0</p>
            </div>
          </div>
          {onClose && (
            <button onClick={onClose} className="lg:hidden p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-white transition-colors">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <div className="px-3 py-2 rounded-xl bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/20">
          <div className="flex items-center justify-between text-xs">
            <span className="text-purple-300 font-medium">لوحة التحكم</span>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              <span className="text-green-400 font-medium">مباشر</span>
            </div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 overflow-y-auto space-y-4">
        {navGroups.map(group => (
          <div key={group.label}>
            <p className="text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest px-3 mb-1">{group.label}</p>
            <div className="space-y-0.5">
              {group.items.map(({ path, label, icon: Icon }) => {
                const isActive = path === "/" ? location === "/" : location.startsWith(path);
                return (
                  <Link key={path} href={path} onClick={onClose}>
                    <div className={cn(
                      "nav-item flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer group transition-all",
                      isActive && "active"
                    )}>
                      <div className={cn(
                        "w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 transition-all",
                        isActive ? "bg-purple-600 shadow-md shadow-purple-500/30" : "bg-transparent group-hover:bg-muted/50"
                      )}>
                        <Icon className={cn(
                          "w-3.5 h-3.5 transition-colors",
                          isActive ? "text-white" : "text-muted-foreground group-hover:text-foreground"
                        )} />
                      </div>
                      <span className={cn(
                        "text-sm font-medium flex-1 transition-colors",
                        isActive ? "text-white" : "text-muted-foreground group-hover:text-foreground"
                      )}>{label}</span>
                      {isActive && <ChevronLeft className="w-3 h-3 text-purple-400" />}
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer stats */}
      <div className="p-4 border-t border-border">
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div className="rounded-xl bg-orange-500/10 border border-orange-500/20 p-2.5 text-center">
            <div className="text-base font-bold text-orange-400 tabular-nums">{totalWarnings ?? "—"}</div>
            <div className="text-[10px] text-muted-foreground mt-0.5">تحذيرات</div>
          </div>
          <div className="rounded-xl bg-red-500/10 border border-red-500/20 p-2.5 text-center">
            <div className="text-base font-bold text-red-400 tabular-nums">{totalMuted ?? "—"}</div>
            <div className="text-[10px] text-muted-foreground mt-0.5">مكتومون</div>
          </div>
        </div>
        <div className="text-center">
          <p className="text-[10px] text-muted-foreground/40">© 2025 RXZ System Bot Pro</p>
        </div>
      </div>
    </aside>
  );
}
