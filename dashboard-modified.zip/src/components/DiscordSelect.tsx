import { useGuilds, useChannels, useRoles } from "@/hooks/useDiscord";
import { DiscordChannel, DiscordGuild, DiscordRole } from "@/lib/api";
import { ChevronDown, Hash, Volume2, Loader2, Server } from "lucide-react";

const CHANNEL_ICONS: Record<number, React.ReactNode> = {
  0: <Hash className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />,
  2: <Volume2 className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />,
};

function SelectWrapper({ children, loading }: { children: React.ReactNode; loading: boolean }) {
  return (
    <div className="relative w-full">
      {children}
      <div className="pointer-events-none absolute inset-y-0 left-3 flex items-center">
        {loading
          ? <Loader2 className="w-3.5 h-3.5 text-muted-foreground animate-spin" />
          : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
        }
      </div>
    </div>
  );
}

const selectClass = "w-full pr-3 pl-8 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white focus:outline-none focus:ring-1 focus:ring-purple-500 appearance-none disabled:opacity-50 cursor-pointer";

export function GuildPicker({ value, onChange }: { value: string; onChange: (id: string) => void }) {
  const { guilds, loading } = useGuilds();
  return (
    <SelectWrapper loading={loading}>
      <select className={selectClass} value={value} onChange={e => onChange(e.target.value)} disabled={loading || guilds.length === 0}>
        <option value="">— اختر سيرفر —</option>
        {guilds.map(g => (
          <option key={g.id} value={g.id}>{g.name} ({g.memberCount?.toLocaleString() ?? "?"} عضو)</option>
        ))}
      </select>
    </SelectWrapper>
  );
}

export function ChannelSelect({
  guildId,
  value,
  onChange,
  placeholder = "— اختر قناة —",
  types,
}: {
  guildId: string;
  value: string;
  onChange: (id: string) => void;
  placeholder?: string;
  types?: number[];
}) {
  const { channels, loading } = useChannels(guildId || null);
  const filtered = types ? channels.filter(c => types.includes(c.type)) : channels;

  return (
    <SelectWrapper loading={loading}>
      <select
        className={selectClass}
        value={value}
        onChange={e => onChange(e.target.value)}
        disabled={loading || !guildId}
      >
        <option value="">{!guildId ? "— اختر سيرفر أولاً —" : placeholder}</option>
        {filtered.map(c => (
          <option key={c.id} value={c.id}>
            {c.type === 2 ? "🔊" : c.type === 4 ? "📁" : "#"} {c.name}
          </option>
        ))}
      </select>
    </SelectWrapper>
  );
}

export function RoleSelect({
  guildId,
  value,
  onChange,
  placeholder = "— اختر رتبة —",
}: {
  guildId: string;
  value: string;
  onChange: (id: string) => void;
  placeholder?: string;
}) {
  const { roles, loading } = useRoles(guildId || null);

  return (
    <SelectWrapper loading={loading}>
      <select
        className={selectClass}
        value={value}
        onChange={e => onChange(e.target.value)}
        disabled={loading || !guildId}
      >
        <option value="">{!guildId ? "— اختر سيرفر أولاً —" : placeholder}</option>
        {roles.map(r => (
          <option key={r.id} value={r.id}>
            🎭 {r.name}
          </option>
        ))}
      </select>
    </SelectWrapper>
  );
}

export function MultiRoleSelect({
  guildId,
  value,
  onChange,
}: {
  guildId: string;
  value: string[];
  onChange: (ids: string[]) => void;
}) {
  const { roles, loading } = useRoles(guildId || null);

  const toggle = (id: string) => {
    if (value.includes(id)) onChange(value.filter(v => v !== id));
    else onChange([...value, id]);
  };

  if (!guildId) return <p className="text-xs text-muted-foreground py-2">اختر سيرفر أولاً</p>;
  if (loading) return <div className="flex items-center gap-2 text-xs text-muted-foreground py-2"><Loader2 className="w-3 h-3 animate-spin" />جاري التحميل…</div>;

  return (
    <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
      {roles.map(r => {
        const selected = value.includes(r.id);
        return (
          <button
            key={r.id}
            type="button"
            onClick={() => toggle(r.id)}
            className={`px-2.5 py-1 rounded-full text-xs font-medium transition-colors border ${
              selected
                ? "bg-purple-600/30 border-purple-500/50 text-purple-300"
                : "bg-muted/30 border-border text-muted-foreground hover:border-purple-500/30"
            }`}
          >
            {selected ? "✓ " : ""}{r.name}
          </button>
        );
      })}
      {roles.length === 0 && <p className="text-xs text-muted-foreground">لا توجد رتب</p>}
    </div>
  );
}

export function GuildHeader({ guildId, onGuildChange }: { guildId: string; onGuildChange: (id: string) => void }) {
  const { guilds } = useGuilds();
  const guild = guilds.find(g => g.id === guildId);

  return (
    <div className="flex items-center gap-3 p-3 bg-muted/10 border border-border rounded-xl mb-1">
      <Server className="w-4 h-4 text-purple-400 flex-shrink-0" />
      <span className="text-sm font-medium text-white flex-1">السيرفر</span>
      <div className="w-56">
        <GuildPicker value={guildId} onChange={onGuildChange} />
      </div>
    </div>
  );
}
