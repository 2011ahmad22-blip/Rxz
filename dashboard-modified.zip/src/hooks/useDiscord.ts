import { useEffect, useState, createContext, useContext } from "react";
import { api, DiscordGuild, DiscordChannel, DiscordRole } from "@/lib/api";

export function useGuilds() {
  const [guilds, setGuilds] = useState<DiscordGuild[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    api.getGuilds().then(setGuilds).catch(() => {}).finally(() => setLoading(false));
  }, []);
  return { guilds, loading };
}

export function useChannels(guildId: string | null) {
  const [channels, setChannels] = useState<DiscordChannel[]>([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (!guildId) { setChannels([]); return; }
    setLoading(true);
    api.getChannels(guildId).then(setChannels).catch(() => {}).finally(() => setLoading(false));
  }, [guildId]);
  return { channels, loading };
}

export function useRoles(guildId: string | null) {
  const [roles, setRoles] = useState<DiscordRole[]>([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (!guildId) { setRoles([]); return; }
    setLoading(true);
    api.getRoles(guildId).then(setRoles).catch(() => {}).finally(() => setLoading(false));
  }, [guildId]);
  return { roles, loading };
}
