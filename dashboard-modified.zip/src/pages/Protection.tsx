import { useEffect, useState } from "react";
import { api, BotConfig, ProtectionSettings } from "@/lib/api";
import { Zap, Save, ShieldAlert, MessageSquareX, Volume2, AtSign, Link } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Protection() {
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [swearInput, setSwearInput] = useState("");
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    api.getConfig().then((c) => {
      setConfig(c);
      setSwearInput((c.protection.swearWords || []).join(", "));
    }).catch(() => {});
  }, []);

  const save = async () => {
    if (!config) return;
    setSaving(true);
    const words = swearInput.split(",").map((w) => w.trim()).filter(Boolean);
    try {
      await api.updateConfig({ protection: { ...config.protection, swearWords: words } });
      toast({ title: "✅ تم الحفظ", description: "تم تحديث إعدادات الحماية." });
    } catch {
      toast({ title: "خطأ", description: "فشل في الحفظ.", variant: "destructive" });
    } finally { setSaving(false); }
  };

  const setP = (key: keyof ProtectionSettings, val: unknown) => {
    if (!config) return;
    setConfig({ ...config, protection: { ...config.protection, [key]: val } });
  };

  if (!config) return <div className="space-y-4">{[...Array(4)].map((_, i) => <div key={i} className="stat-card rounded-xl p-5 h-36 animate-pulse" />)}</div>;

  const p = config.protection;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">الحماية</h2>
          <p className="text-muted-foreground text-sm mt-0.5">الحماية التلقائية وفلاتر المحادثات</p>
        </div>
        <button onClick={save} disabled={saving} className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium text-sm transition-colors disabled:opacity-50">
          <Save className="w-4 h-4" />
          {saving ? "جاري الحفظ…" : "حفظ التغييرات"}
        </button>
      </div>

      <Card icon={<MessageSquareX className="w-4 h-4 text-red-400" />} title="فلتر الشتائم">
        <Toggle label="تفعيل فلتر الشتائم" desc="حذف الرسائل التي تحتوي على كلمات محظورة" value={p.antiSwear} onChange={(v) => setP("antiSwear", v)} />
        <div>
          <label className="text-sm font-medium text-white block mb-1">الكلمات المحظورة</label>
          <p className="text-xs text-muted-foreground mb-2">افصل بين الكلمات بفاصلة ( , )</p>
          <textarea className="w-full px-3 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-purple-500 resize-none" rows={3} placeholder="كلمة1, كلمة2, word3" value={swearInput} onChange={(e) => setSwearInput(e.target.value)} />
          <p className="text-xs text-muted-foreground mt-1">{swearInput.split(",").filter(w => w.trim()).length} كلمة مضافة</p>
        </div>
      </Card>

      <Card icon={<Volume2 className="w-4 h-4 text-yellow-400" />} title="فلتر الكابس (Anti-Caps)">
        <Toggle label="تفعيل فلتر الكابس" desc="حذف الرسائل التي تحتوي على أحرف كبيرة بشكل مفرط" value={p.antiCaps} onChange={(v) => setP("antiCaps", v)} />
        <NumField label="نسبة الكابس %" desc="النسبة التي تُفعّل الفلتر (الافتراضي 70%)" value={p.capsPercent} onChange={(v) => setP("capsPercent", v)} min={10} max={100} />
      </Card>

      <Card icon={<AtSign className="w-4 h-4 text-blue-400" />} title="فلتر الإشارات المفرطة (Anti-Mention)">
        <Toggle label="تفعيل فلتر الإشارات" desc="حذف الرسائل التي تحتوي على إشارات مفرطة" value={p.antiMentionSpam} onChange={(v) => setP("antiMentionSpam", v)} />
        <NumField label="الحد الأقصى للإشارات" desc="عدد الإشارات المسموح بها في رسالة واحدة" value={p.mentionLimit} onChange={(v) => setP("mentionLimit", v)} min={1} max={50} />
      </Card>

      <Card icon={<Zap className="w-4 h-4 text-orange-400" />} title="مكافحة السبام (Anti-Spam)">
        <Toggle label="تفعيل مكافحة السبام" desc="معاقبة الأعضاء الذين يرسلون رسائل بسرعة كبيرة" value={p.antiSpam} onChange={(v) => setP("antiSpam", v)} />
        <NumField label="عدد الرسائل" desc="عدد الرسائل قبل تطبيق العقوبة" value={p.spamThreshold} onChange={(v) => setP("spamThreshold", v)} min={2} max={30} />
        <NumField label="الفترة الزمنية (مللي ثانية)" desc="النافذة الزمنية لتتبع الرسائل" value={p.spamInterval} onChange={(v) => setP("spamInterval", v)} min={1000} max={60000} step={1000} />
      </Card>

      <Card icon={<ShieldAlert className="w-4 h-4 text-purple-400" />} title="مكافحة الريد (Anti-Raid)">
        <Toggle label="تفعيل مكافحة الريد" desc="قفل السيرفر عند انضمام عدد كبير من الحسابات بسرعة" value={p.antiRaid} onChange={(v) => setP("antiRaid", v)} />
        <NumField label="حد الانضمام" desc="عدد الانضمامات التي تُفعّل القفل" value={p.raidThreshold} onChange={(v) => setP("raidThreshold", v)} min={2} max={100} />
        <NumField label="الفترة الزمنية (مللي ثانية)" desc="النافذة الزمنية لتتبع الانضمامات" value={p.raidInterval} onChange={(v) => setP("raidInterval", v)} min={1000} max={60000} step={1000} />
        <div className="p-3 rounded-lg bg-orange-500/10 border border-orange-500/20">
          <p className="text-xs text-orange-300">⚠️ عند التفعيل: البوت يقفل السيرفر ويرسل تنبيهاً للأدمن حتى يتم فك القفل يدوياً.</p>
        </div>
      </Card>

      <Card icon={<Link className="w-4 h-4 text-cyan-400" />} title="فلتر الروابط (Anti-Link)">
        <Toggle label="تفعيل فلتر الروابط" desc="حذف الرسائل التي تحتوي على روابط خارجية" value={p.antiLink} onChange={(v) => setP("antiLink", v)} />
      </Card>
    </div>
  );
}

function Card({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="stat-card rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">{icon}<h3 className="font-semibold text-white">{title}</h3></div>
      <div className="space-y-4">{children}</div>
    </div>
  );
}
function Toggle({ label, desc, value, onChange }: { label: string; desc: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div><div className="text-sm font-medium text-white">{label}</div><div className="text-xs text-muted-foreground mt-0.5">{desc}</div></div>
      <button onClick={() => onChange(!value)} className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${value ? "bg-purple-600" : "bg-muted"}`}>
        <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${value ? "left-6" : "left-1"}`} />
      </button>
    </div>
  );
}
function NumField({ label, desc, value, onChange, min, max, step = 1 }: { label: string; desc: string; value: number; onChange: (v: number) => void; min: number; max: number; step?: number }) {
  return (
    <div className="flex items-start justify-between gap-3 flex-wrap">
      <div className="flex-1"><div className="text-sm font-medium text-white">{label}</div><div className="text-xs text-muted-foreground mt-0.5">{desc}</div></div>
      <input type="number" min={min} max={max} step={step} className="w-28 px-3 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white focus:outline-none focus:ring-1 focus:ring-purple-500" value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </div>
  );
}
