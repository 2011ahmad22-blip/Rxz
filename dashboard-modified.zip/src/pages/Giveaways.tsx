import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Gift, Trophy, Clock, Users, RefreshCw } from "lucide-react";

type Giveaway = {
  id: string; channelId: string; messageId: string; prize: string;
  endsAt: number; winnersCount: number; hostId: string; ended: boolean; participants: string[];
};

function timeLeft(endsAt: number) {
  const diff = endsAt - Date.now();
  if (diff <= 0) return "انتهى";
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  if (h > 0) return `${h} ساعة ${m} دقيقة`;
  if (m > 0) return `${m} دقيقة ${s} ثانية`;
  return `${s} ثانية`;
}

export default function Giveaways() {
  const [giveaways, setGiveaways] = useState<Giveaway[]>([]);
  const [loading, setLoading] = useState(true);
  const [, setTick] = useState(0);

  const load = () => {
    setLoading(true);
    api.getGiveaways().then(setGiveaways).catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);
  useEffect(() => { const id = setInterval(() => setTick(t => t + 1), 1000); return () => clearInterval(id); }, []);

  const active = giveaways.filter(g => !g.ended);
  const ended = giveaways.filter(g => g.ended);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">السحوبات</h2>
          <p className="text-muted-foreground text-sm mt-0.5">إدارة سحوبات الجوائز في السيرفر</p>
        </div>
        <button onClick={load} className="flex items-center gap-2 px-3 py-2 bg-muted hover:bg-muted/70 text-white rounded-lg text-sm transition-colors">
          <RefreshCw className="w-4 h-4" />
          تحديث
        </button>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "نشط", value: active.length, icon: Gift, color: "text-green-400" },
          { label: "منتهي", value: ended.length, icon: Trophy, color: "text-yellow-400" },
          { label: "إجمالي المشاركات", value: giveaways.reduce((s, g) => s + g.participants.length, 0), icon: Users, color: "text-purple-400" },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="stat-card rounded-xl p-4 text-center">
            <Icon className={`w-5 h-5 mx-auto mb-2 ${color}`} />
            <div className="text-xl font-bold text-white">{value}</div>
            <div className="text-xs text-muted-foreground">{label}</div>
          </div>
        ))}
      </div>

      <div className="stat-card rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Gift className="w-4 h-4 text-green-400" />
          <h3 className="font-semibold text-white">الجوائز النشطة</h3>
          <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full mr-auto">{active.length} نشط</span>
        </div>
        {loading ? (
          <div className="space-y-3">{[...Array(2)].map((_, i) => <div key={i} className="h-20 bg-muted/30 rounded-lg animate-pulse" />)}</div>
        ) : active.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground">
            <Gift className="w-10 h-10 mx-auto mb-3 opacity-20" />
            <p className="text-sm">لا توجد سحوبات نشطة</p>
            <p className="text-xs mt-1">استخدم <code className="text-purple-300">/giveaway start</code> في ديسكورد</p>
          </div>
        ) : active.map(g => <GiveawayCard key={g.id} g={g} tl={timeLeft(g.endsAt)} />)}
      </div>

      {ended.length > 0 && (
        <div className="stat-card rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="w-4 h-4 text-yellow-400" />
            <h3 className="font-semibold text-white">السحوبات المنتهية</h3>
          </div>
          <div className="space-y-3">{ended.map(g => <GiveawayCard key={g.id} g={g} tl="انتهى" />)}</div>
        </div>
      )}

      <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/20">
        <h4 className="text-sm font-semibold text-purple-300 mb-2">🎉 أوامر السحوبات</h4>
        <div className="space-y-1 text-xs text-purple-200">
          <p><code className="bg-purple-900/40 px-1 rounded">/giveaway start [مدة] [عدد الفائزين] [الجائزة]</code></p>
          <p><code className="bg-purple-900/40 px-1 rounded">/giveaway end [messageId]</code> — إنهاء مبكر</p>
          <p><code className="bg-purple-900/40 px-1 rounded">/giveaway reroll [messageId]</code> — إعادة السحب</p>
        </div>
      </div>
    </div>
  );
}

function GiveawayCard({ g, tl }: { g: Giveaway; tl: string }) {
  return (
    <div className={`p-4 rounded-lg border ${g.ended ? "bg-muted/10 border-border" : "bg-green-500/5 border-green-500/20"}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${g.ended ? "bg-muted text-muted-foreground" : "bg-green-500/20 text-green-400"}`}>
              {g.ended ? "انتهى" : "نشط"}
            </span>
          </div>
          <h4 className="font-semibold text-white truncate">🎁 {g.prize}</h4>
          <p className="text-xs text-muted-foreground mt-1">المضيف: …{g.hostId.slice(-4)}</p>
        </div>
        <div className="text-right flex-shrink-0 space-y-1">
          <div className="flex items-center gap-1 text-xs text-muted-foreground"><Clock className="w-3 h-3" /><span>{tl}</span></div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground"><Users className="w-3 h-3" /><span>{g.participants.length} مشارك</span></div>
          <div className="flex items-center gap-1 text-xs text-purple-400"><Trophy className="w-3 h-3" /><span>{g.winnersCount} فائز</span></div>
        </div>
      </div>
    </div>
  );
}
