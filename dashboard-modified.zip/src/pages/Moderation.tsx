import { useEffect, useState } from "react";
import { api, BotConfig } from "@/lib/api";
import { Shield, AlertTriangle, Save, Trash2, RefreshCw, ChevronDown, ChevronUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { GuildHeader, ChannelSelect, RoleSelect, MultiRoleSelect } from "@/components/DiscordSelect";
import { useGuilds } from "@/hooks/useDiscord";

const ACTIONS: Record<string, string> = {
  none: "لا شيء",
  timeout: "تايم أوت",
  kick: "كيك",
  ban: "باند",
};

type Warning = { reason: string; by: string; at: number };
type WarningsMap = Record<string, Warning[]>;

export default function Moderation() {
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [warnings, setWarnings] = useState<WarningsMap>({});
  const [saving, setSaving] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [guildId, setGuildId] = useState("");
  const { guilds } = useGuilds();
  const { toast } = useToast();

  useEffect(() => { api.getConfig().then(setConfig).catch(() => {}); loadWarnings(); }, []);
  useEffect(() => { if (guilds.length === 1 && !guildId) setGuildId(guilds[0].id); }, [guilds]);

  const loadWarnings = () => api.getWarnings().then(setWarnings).catch(() => {});

  const save = async () => {
    if (!config) return;
    setSaving(true);
    try {
      await api.updateConfig({
        prefix: config.prefix,
        logsChannel: config.logsChannel,
        muteRole: config.muteRole,
        modRoles: config.modRoles,
        autoRoles: config.autoRoles,
        warnPunishments: config.warnPunishments,
        autoMod: config.autoMod,
      });
      toast({ title: "✅ تم الحفظ", description: "تم تحديث إعدادات الإشراف." });
    } catch {
      toast({ title: "خطأ", description: "فشل في الحفظ.", variant: "destructive" });
    } finally { setSaving(false); }
  };

  const clearWarnings = async (userId: string) => {
    setDeleting(userId);
    try {
      await api.deleteWarnings(userId);
      setWarnings(prev => { const n = { ...prev }; delete n[userId]; return n; });
      toast({ title: "✅ تم المسح", description: "تم مسح تحذيرات العضو." });
    } catch {
      toast({ title: "خطأ", description: "فشل في مسح التحذيرات.", variant: "destructive" });
    } finally { setDeleting(null); }
  };

  const setWarnAction = (i: number, action: string) => {
    if (!config) return;
    const updated = [...config.warnPunishments];
    updated[i] = { ...updated[i], action };
    setConfig({ ...config, warnPunishments: updated });
  };

  const totalWarnings = Object.values(warnings).reduce((s, w) => s + w.length, 0);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">الإشراف</h2>
          <p className="text-muted-foreground text-sm mt-0.5">إعدادات العقوبات وقنوات السجل</p>
        </div>
        <button onClick={save} disabled={saving || !config} className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium text-sm transition-colors disabled:opacity-50">
          <Save className="w-4 h-4" />
          {saving ? "جاري الحفظ…" : "حفظ التغييرات"}
        </button>
      </div>

      <GuildHeader guildId={guildId} onGuildChange={setGuildId} />

      {/* Warnings */}
      <div className="stat-card rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="w-4 h-4 text-orange-400" />
          <h3 className="font-semibold text-white">سجل التحذيرات</h3>
          <span className="text-xs bg-orange-500/20 text-orange-400 px-2 py-0.5 rounded-full mr-auto">{totalWarnings} تحذير</span>
          <button onClick={loadWarnings} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-white transition-colors">
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
        {Object.keys(warnings).length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <AlertTriangle className="w-10 h-10 mx-auto mb-2 opacity-20" />
            <p className="text-sm">لا توجد تحذيرات حتى الآن</p>
          </div>
        ) : (
          <div className="space-y-2">
            {Object.entries(warnings).map(([userId, warnList]) => (
              <div key={userId} className="rounded-lg border border-border overflow-hidden">
                <div className="flex items-center gap-3 p-3 cursor-pointer hover:bg-muted/20 transition-colors" onClick={() => setExpanded(expanded === userId ? null : userId)}>
                  <div className="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-bold text-orange-400">{warnList.length}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-mono text-white truncate">…{userId.slice(-8)}</p>
                    <p className="text-xs text-muted-foreground">آخر تحذير: {new Date(warnList[warnList.length - 1]?.at ?? 0).toLocaleDateString("ar-SA")}</p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button onClick={(e) => { e.stopPropagation(); clearWarnings(userId); }} disabled={deleting === userId} className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition-colors disabled:opacity-50" title="مسح">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    {expanded === userId ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                  </div>
                </div>
                {expanded === userId && (
                  <div className="border-t border-border divide-y divide-border">
                    {warnList.map((w, i) => (
                      <div key={i} className="flex items-start gap-3 px-4 py-2.5 bg-muted/10">
                        <span className="text-xs text-orange-400 font-bold w-5 flex-shrink-0">#{i + 1}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-white">{w.reason}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">بواسطة: {w.by} — {new Date(w.at).toLocaleString("ar-SA")}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {config && (
        <>
          <div className="stat-card rounded-xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-4 h-4 text-blue-400" />
              <h3 className="font-semibold text-white">الإعدادات الأساسية</h3>
            </div>
            <div className="space-y-4">
              <Row label="البريفيكس" desc="رمز الأوامر النصية">
                <input className="w-full px-3 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white focus:outline-none focus:ring-1 focus:ring-purple-500" value={config.prefix} onChange={(e) => setConfig({ ...config, prefix: e.target.value })} placeholder="!" />
              </Row>
              <Row label="قناة سجل الإشراف" desc="تُسجَّل فيها إجراءات الإشراف">
                <ChannelSelect guildId={guildId} value={config.logsChannel || ""} onChange={(v) => setConfig({ ...config, logsChannel: v || null })} types={[0]} placeholder="— اختر قناة —" />
              </Row>
              <Row label="رتبة الكتم" desc="تُعطى عند الميوت">
                <RoleSelect guildId={guildId} value={config.muteRole || ""} onChange={(v) => setConfig({ ...config, muteRole: v || null })} placeholder="— اختر رتبة —" />
              </Row>
              <Row label="رتبة الانضمام التلقائي" desc="تُعطى للأعضاء الجدد">
                <RoleSelect guildId={guildId} value={config.autoRoles[0] || ""} onChange={(v) => setConfig({ ...config, autoRoles: v ? [v] : [] })} placeholder="— اختر رتبة —" />
              </Row>
              <div>
                <div className="text-sm font-medium text-white mb-1">رتب المشرفين</div>
                <div className="text-xs text-muted-foreground mb-2">الرتب التي تملك صلاحيات الإشراف</div>
                <MultiRoleSelect guildId={guildId} value={config.modRoles} onChange={(ids) => setConfig({ ...config, modRoles: ids })} />
              </div>
            </div>
          </div>

          <div className="stat-card rounded-xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle className="w-4 h-4 text-orange-400" />
              <h3 className="font-semibold text-white">عقوبات التحذيرات التلقائية</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-3">يُعاقب العضو تلقائياً عند الوصول لعدد التحذيرات</p>
            <div className="space-y-3">
              {config.warnPunishments.map((wp, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-muted/20 rounded-lg">
                  <div className="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-bold text-orange-400">{wp.count}</span>
                  </div>
                  <div className="flex-1 text-sm text-white">عند {wp.count} تحذيرات</div>
                  <select value={wp.action} onChange={(e) => setWarnAction(i, e.target.value)} className="px-3 py-1.5 bg-muted/50 border border-border rounded-lg text-sm text-white focus:outline-none focus:ring-1 focus:ring-purple-500">
                    {Object.entries(ACTIONS).map(([val, label]) => (
                      <option key={val} value={val} className="bg-card">{label}</option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          </div>

          <div className="stat-card rounded-xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-4 h-4 text-green-400" />
              <h3 className="font-semibold text-white">المراقبة التلقائية</h3>
            </div>
            <div className="space-y-4">
              <Toggle label="حذف الرسالة المخالفة" desc="عند انتهاك قواعد الحماية" value={config.autoMod.deleteWarning} onChange={(v) => setConfig({ ...config, autoMod: { ...config.autoMod, deleteWarning: v } })} />
              <Toggle label="تحذير عند الانتهاك" desc="أعطِ تحذيراً تلقائياً لكل مخالفة" value={config.autoMod.warnOnViolation} onChange={(v) => setConfig({ ...config, autoMod: { ...config.autoMod, warnOnViolation: v } })} />
              <Toggle label="كتم عند التكرار" desc="اكتم العضو عند تكرار المخالفة" value={config.autoMod.muteOnRepeatViolation} onChange={(v) => setConfig({ ...config, autoMod: { ...config.autoMod, muteOnRepeatViolation: v } })} />
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function Row({ label, desc, children }: { label: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 flex-wrap">
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium text-white">{label}</div>
        {desc && <div className="text-xs text-muted-foreground mt-0.5">{desc}</div>}
      </div>
      <div className="w-full sm:w-52">{children}</div>
    </div>
  );
}

function Toggle({ label, desc, value, onChange }: { label: string; desc: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div><div className="text-sm font-medium text-white">{label}</div><div className="text-xs text-muted-foreground mt-0.5">{desc}</div></div>
      <button onClick={() => onChange(!value)} className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${value ? "bg-purple-600" : "bg-muted"}`}>
        <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${value ? "left-6" : "left-1"}`} />
      </button>
    </div>
  );
}
