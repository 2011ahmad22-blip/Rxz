import { useState, useEffect, useMemo } from "react";
import { api } from "@/lib/api";
import { GitMerge, Save, X, Search, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type CommandEntry = { name: string; category: string; color: string; desc: string };

const ALL_COMMANDS: CommandEntry[] = [
  // ── الإشراف ──────────────────────────────────────────────
  { name: "ban",          category: "الإشراف",           color: "text-red-400",    desc: "حظر عضو من السيرفر" },
  { name: "unban",        category: "الإشراف",           color: "text-red-400",    desc: "رفع الحظر بـ ID" },
  { name: "kick",         category: "الإشراف",           color: "text-red-400",    desc: "طرد عضو" },
  { name: "mute",         category: "الإشراف",           color: "text-red-400",    desc: "كتم عضو" },
  { name: "unmute",       category: "الإشراف",           color: "text-red-400",    desc: "رفع الكتم" },
  { name: "timeout",      category: "الإشراف",           color: "text-red-400",    desc: "تايم أوت مؤقت" },
  { name: "untimeout",    category: "الإشراف",           color: "text-red-400",    desc: "رفع التايم أوت" },
  { name: "softban",      category: "الإشراف",           color: "text-red-400",    desc: "حظر مؤقت + مسح الرسائل" },
  { name: "tempban",      category: "الإشراف",           color: "text-red-400",    desc: "حظر مؤقت بمدة محددة" },
  { name: "warn",         category: "الإشراف",           color: "text-red-400",    desc: "إعطاء تحذير لعضو" },
  { name: "warnings",     category: "الإشراف",           color: "text-red-400",    desc: "عرض تحذيرات عضو" },
  { name: "clearwarns",   category: "الإشراف",           color: "text-red-400",    desc: "مسح تحذيرات عضو" },
  { name: "nick",         category: "الإشراف",           color: "text-red-400",    desc: "تغيير لقب عضو" },
  { name: "clear",        category: "الإشراف",           color: "text-red-400",    desc: "حذف رسائل من القناة" },
  { name: "role",         category: "الإشراف",           color: "text-red-400",    desc: "إضافة/إزالة رتبة" },
  { name: "lock",         category: "الإشراف",           color: "text-red-400",    desc: "قفل القناة" },
  { name: "unlock",       category: "الإشراف",           color: "text-red-400",    desc: "فتح القناة" },
  { name: "slowmode",     category: "الإشراف",           color: "text-red-400",    desc: "تفعيل السلو مود" },
  // ── المعلومات ────────────────────────────────────────────
  { name: "ping",         category: "المعلومات",         color: "text-blue-400",   desc: "سرعة استجابة البوت" },
  { name: "botinfo",      category: "المعلومات",         color: "text-blue-400",   desc: "معلومات البوت" },
  { name: "userinfo",     category: "المعلومات",         color: "text-blue-400",   desc: "معلومات عضو" },
  { name: "serverinfo",   category: "المعلومات",         color: "text-blue-400",   desc: "معلومات السيرفر" },
  { name: "avatar",       category: "المعلومات",         color: "text-blue-400",   desc: "صورة العضو" },
  { name: "help",         category: "المعلومات",         color: "text-blue-400",   desc: "قائمة الأوامر" },
  // ── المستويات ────────────────────────────────────────────
  { name: "level",        category: "المستويات والـ XP", color: "text-purple-400", desc: "مستواك ونقاط XP" },
  { name: "leaderboard",  category: "المستويات والـ XP", color: "text-purple-400", desc: "لوحة المتصدرين" },
  // ── التذاكر ──────────────────────────────────────────────
  { name: "ticket setup", category: "نظام التذاكر",     color: "text-yellow-400", desc: "إنشاء لوحة تذاكر" },
  { name: "ticket close", category: "نظام التذاكر",     color: "text-yellow-400", desc: "إغلاق التذكرة" },
  { name: "ticket add",   category: "نظام التذاكر",     color: "text-yellow-400", desc: "إضافة عضو للتذكرة" },
  { name: "ticket claim", category: "نظام التذاكر",     color: "text-yellow-400", desc: "استلام التذكرة" },
];

const CATEGORIES = [...new Set(ALL_COMMANDS.map(c => c.category))];

export default function Aliases() {
  const [aliases, setAliases] = useState<Record<string, string>>({});
  const [search, setSearch]   = useState("");
  const [saving, setSaving]   = useState(false);
  const [loaded, setLoaded]   = useState(false);
  const { toast } = useToast();

  // تحميل الاختصارات الحالية
  useEffect(() => {
    api.getConfig()
      .then(cfg => { setAliases(cfg.commandAliases ?? {}); setLoaded(true); })
      .catch(() => setLoaded(true));
  }, []);

  const setAlias = (cmd: string, value: string) => {
    const clean = value.trim().toLowerCase().replace(/\s+/g, "");
    setAliases(prev => ({ ...prev, [cmd]: clean }));
  };

  const clearAlias = (cmd: string) => {
    setAliases(prev => { const n = { ...prev }; delete n[cmd]; return n; });
  };

  const save = async () => {
    setSaving(true);
    try {
      const cleaned: Record<string, string> = {};
      for (const [cmd, alias] of Object.entries(aliases)) {
        if (alias && alias.trim()) cleaned[cmd] = alias.trim();
      }
      await api.updateConfig({ commandAliases: cleaned });
      toast({ title: "✅ تم الحفظ", description: "تم حفظ الاختصارات بنجاح." });
    } catch {
      toast({ title: "خطأ", description: "فشل في الحفظ.", variant: "destructive" });
    } finally { setSaving(false); }
  };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return ALL_COMMANDS;
    return ALL_COMMANDS.filter(c =>
      c.name.includes(q) || c.desc.includes(q) || (aliases[c.name] ?? "").includes(q)
    );
  }, [search, aliases]);

  const setCount = Object.values(aliases).filter(Boolean).length;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">الاختصارات</h2>
          <p className="text-muted-foreground text-sm mt-0.5">
            حدّد اختصاراً لكل أمر — اكتبه في الخانة المقابلة
            {setCount > 0 && (
              <span className="mr-2 text-xs px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/20">
                {setCount} مُعيَّن
              </span>
            )}
          </p>
        </div>
        <button
          onClick={save}
          disabled={saving || !loaded}
          className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium text-sm transition-colors disabled:opacity-50"
        >
          <Save className="w-4 h-4" />
          {saving ? "جاري الحفظ…" : "حفظ التغييرات"}
        </button>
      </div>

      {/* Info */}
      <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
        <div className="flex items-start gap-3">
          <GitMerge className="w-4 h-4 text-blue-300 mt-0.5 flex-shrink-0" />
          <div className="text-xs text-blue-200 leading-relaxed">
            اكتب الاختصار في الخانة الفارغة بجانب كل أمر.
            مثال: اكتب <code className="bg-blue-900/40 px-1 rounded">b</code> بجانب{" "}
            <code className="bg-blue-900/40 px-1 rounded">ban</code> — وبعدها يكفي كتابة{" "}
            <code className="bg-blue-900/40 px-1 rounded">!b @user سبب</code> بدل{" "}
            <code className="bg-blue-900/40 px-1 rounded">!ban @user سبب</code>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
        <input
          className="w-full pr-10 pl-4 py-2.5 bg-muted/40 border border-border rounded-xl text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-purple-500 focus:border-purple-500/50"
          placeholder="ابحث عن أمر…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {/* Commands by category */}
      {CATEGORIES.map(cat => {
        const cmds = filtered.filter(c => c.category === cat);
        if (!cmds.length) return null;
        return (
          <div key={cat} className="stat-card rounded-xl overflow-hidden">
            {/* Category header */}
            <div className="flex items-center gap-2 px-5 py-3 border-b border-border bg-muted/10">
              <GitMerge className={`w-4 h-4 ${cmds[0].color}`} />
              <span className="font-semibold text-white text-sm">{cat}</span>
              <span className="mr-auto text-xs text-muted-foreground">{cmds.length} أوامر</span>
            </div>

            {/* Command rows */}
            <div className="divide-y divide-border">
              {cmds.map(cmd => {
                const alias = aliases[cmd.name] ?? "";
                const hasAlias = alias.length > 0;
                return (
                  <div key={cmd.name} className="flex items-center gap-3 px-5 py-3 hover:bg-muted/10 transition-colors">
                    {/* Command info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <code className={`text-sm font-mono font-semibold ${cmd.color}`}>
                          /{cmd.name}
                        </code>
                        {hasAlias && (
                          <span className="flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-green-500/15 text-green-400 border border-green-500/20">
                            <CheckCircle className="w-2.5 h-2.5" />
                            مُعيَّن
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">{cmd.desc}</p>
                    </div>

                    {/* Preview */}
                    {hasAlias ? (
                      <div className="hidden sm:flex items-center gap-1.5 text-xs text-muted-foreground flex-shrink-0">
                        <code className="text-purple-300 bg-purple-500/10 px-2 py-1 rounded font-mono">
                          !{alias}
                        </code>
                        <span className="text-muted-foreground">←</span>
                        <code className="text-blue-300 font-mono">/{cmd.name}</code>
                      </div>
                    ) : (
                      <div className="hidden sm:block text-xs text-muted-foreground/40 italic flex-shrink-0">
                        لا يوجد اختصار
                      </div>
                    )}

                    {/* Input */}
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <div className="relative">
                        <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-mono">!</span>
                        <input
                          className={`w-28 pl-3 pr-6 py-1.5 bg-muted/50 border rounded-lg text-sm font-mono text-white placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 transition-colors ${
                            hasAlias
                              ? "border-purple-500/50 focus:ring-purple-500 bg-purple-500/5"
                              : "border-border focus:ring-purple-500 focus:border-purple-500/50"
                          }`}
                          placeholder="اكتب هنا"
                          value={alias}
                          maxLength={15}
                          onChange={e => setAlias(cmd.name, e.target.value)}
                          dir="ltr"
                        />
                      </div>
                      {hasAlias && (
                        <button
                          onClick={() => clearAlias(cmd.name)}
                          className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition-colors"
                          title="مسح الاختصار"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}

      {filtered.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <GitMerge className="w-12 h-12 mx-auto mb-3 opacity-20" />
          <p className="text-sm">لم يتم العثور على أوامر مطابقة لـ "{search}"</p>
        </div>
      )}

      {/* Save reminder */}
      {setCount > 0 && (
        <div className="sticky bottom-4 flex justify-center">
          <div className="flex items-center gap-3 px-5 py-3 bg-card border border-purple-500/30 rounded-2xl shadow-lg shadow-purple-500/10">
            <span className="text-sm text-white">{setCount} اختصار جاهز للحفظ</span>
            <button
              onClick={save}
              disabled={saving}
              className="flex items-center gap-2 px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              {saving ? "جاري الحفظ…" : "حفظ"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
