import { useEffect, useState } from "react";
import { api, BotConfig } from "@/lib/api";
import { Ticket, Save, Hash, Users, MessageSquare, Star, Settings, Palette, Clock, Bell, FileText, ChevronDown, ChevronUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { GuildHeader, ChannelSelect, RoleSelect, MultiRoleSelect } from "@/components/DiscordSelect";
import { useGuilds } from "@/hooks/useDiscord";

type TS = BotConfig["ticketSettings"];

export default function Tickets() {
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [saving, setSaving] = useState(false);
  const [guildId, setGuildId] = useState("");
  const [openSection, setOpenSection] = useState<string>("basic");
  const { guilds } = useGuilds();
  const { toast } = useToast();

  useEffect(() => { api.getConfig().then(setConfig).catch(() => {}); }, []);
  useEffect(() => { if (guilds.length === 1 && !guildId) setGuildId(guilds[0].id); }, [guilds]);

  const save = async () => {
    if (!config) return;
    setSaving(true);
    try {
      await api.updateConfig({ ticketSettings: config.ticketSettings });
      toast({ title: "✅ تم الحفظ", description: "تم تحديث إعدادات التذاكر." });
    } catch {
      toast({ title: "خطأ", description: "فشل في الحفظ.", variant: "destructive" });
    } finally { setSaving(false); }
  };

  const set = <K extends keyof TS>(key: K, val: TS[K]) => {
    if (!config) return;
    setConfig({ ...config, ticketSettings: { ...config.ticketSettings, [key]: val } });
  };

  if (!config) return (
    <div className="space-y-4">{[...Array(4)].map((_, i) => <div key={i} className="stat-card rounded-xl p-5 h-36 animate-pulse" />)}</div>
  );

  const t = config.ticketSettings;

  const sections: { id: string; label: string; icon: React.ReactNode; color: string }[] = [
    { id: "basic", label: "الإعدادات الأساسية", icon: <Ticket className="w-4 h-4" />, color: "text-purple-400" },
    { id: "panel", label: "لوحة التذاكر والزر", icon: <Palette className="w-4 h-4" />, color: "text-blue-400" },
    { id: "channels", label: "القنوات والرتب", icon: <Hash className="w-4 h-4" />, color: "text-green-400" },
    { id: "behavior", label: "سلوك التذاكر", icon: <Settings className="w-4 h-4" />, color: "text-orange-400" },
    { id: "autoclose", label: "الإغلاق التلقائي", icon: <Clock className="w-4 h-4" />, color: "text-red-400" },
    { id: "rating", label: "نظام التقييم ⭐", icon: <Star className="w-4 h-4" />, color: "text-yellow-400" },
    { id: "messages", label: "الرسائل والنصوص", icon: <MessageSquare className="w-4 h-4" />, color: "text-pink-400" },
  ];

  const Section = ({ id, children }: { id: string; children: React.ReactNode }) => {
    const sec = sections.find(s => s.id === id)!;
    const isOpen = openSection === id;
    return (
      <div className={`stat-card rounded-xl overflow-hidden border transition-colors ${isOpen ? "border-purple-500/30" : "border-border"}`}>
        <button
          onClick={() => setOpenSection(isOpen ? "" : id)}
          className="w-full flex items-center gap-3 p-4 text-right hover:bg-muted/10 transition-colors"
        >
          <span className={sec.color}>{sec.icon}</span>
          <span className="font-semibold text-white flex-1">{sec.label}</span>
          {isOpen ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
        </button>
        {isOpen && <div className="px-5 pb-5 space-y-4 border-t border-border pt-4">{children}</div>}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">نظام التذاكر</h2>
          <p className="text-muted-foreground text-sm mt-0.5">إعداد نظام دعم التذاكر للأعضاء بالكامل</p>
        </div>
        <button onClick={save} disabled={saving} className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium text-sm transition-colors disabled:opacity-50 shadow-lg shadow-purple-500/20">
          <Save className="w-4 h-4" />
          {saving ? "جاري الحفظ…" : "حفظ التغييرات"}
        </button>
      </div>

      <GuildHeader guildId={guildId} onGuildChange={setGuildId} />

      {/* Enable toggle — always visible */}
      <div className={`rounded-xl p-4 border flex items-center justify-between gap-3 ${t.enabled ? "bg-green-500/5 border-green-500/30" : "bg-muted/10 border-border"}`}>
        <div className="flex items-center gap-3">
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${t.enabled ? "bg-green-500/20" : "bg-muted/30"}`}>
            <Ticket className={`w-4 h-4 ${t.enabled ? "text-green-400" : "text-muted-foreground"}`} />
          </div>
          <div>
            <p className="font-semibold text-white">نظام التذاكر</p>
            <p className="text-xs text-muted-foreground">{t.enabled ? "✅ مفعّل — الأعضاء يمكنهم فتح تذاكر" : "❌ معطّل — لا يمكن فتح تذاكر"}</p>
          </div>
        </div>
        <button onClick={() => set("enabled", !t.enabled)} className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 ${t.enabled ? "bg-green-500" : "bg-muted"}`}>
          <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all shadow ${t.enabled ? "left-7" : "left-1"}`} />
        </button>
      </div>

      {/* ── SECTION 1: Basic ── */}
      <Section id="basic">
        <Row label="فئة التذاكر" desc="الفئة التي تُنشأ فيها قنوات التذاكر">
          <ChannelSelect guildId={guildId} value={t.categoryId || ""} onChange={v => set("categoryId", v || null)} types={[4]} placeholder="— اختر فئة (Category) —" />
        </Row>
        <Row label="الحد الأقصى للتذاكر" desc="أقصى عدد تذاكر مفتوحة لكل عضو (0 = غير محدود)">
          <input type="number" min={0} max={10} className={inputCls} value={t.maxTicketsPerUser} onChange={e => set("maxTicketsPerUser", parseInt(e.target.value) || 0)} />
        </Row>
        <Row label="صيغة اسم التذكرة" desc="اسم قناة التذكرة عند فتحها">
          <select className={inputCls} value={t.ticketNameFormat} onChange={e => set("ticketNameFormat", e.target.value)}>
            <option value="ticket-{username}">ticket-اسم_العضو</option>
            <option value="ticket-{number}">ticket-رقم</option>
            <option value="support-{username}">support-اسم_العضو</option>
            <option value="help-{username}">help-اسم_العضو</option>
            <option value="{username}-ticket">{"{username}"}-ticket</option>
          </select>
        </Row>
        <Toggle label="تفعيل خاصية Claim" desc="السماح لأعضاء الدعم بالمطالبة بالمسؤولية عن التذكرة" value={t.claimEnabled} onChange={v => set("claimEnabled", v)} />
        {t.claimEnabled && (
          <Row label="رتبة Claim" desc="الرتبة التي يمكنها المطالبة بالتذاكر">
            <RoleSelect guildId={guildId} value={t.claimRole || ""} onChange={v => set("claimRole", v || null)} placeholder="— اختر رتبة —" />
          </Row>
        )}
      </Section>

      {/* ── SECTION 2: Panel ── */}
      <Section id="panel">
        <Row label="عنوان اللوحة" desc="عنوان Embed لوحة التذاكر">
          <input className={inputCls} value={t.panelTitle} onChange={e => set("panelTitle", e.target.value)} placeholder="🎫 نظام التذاكر" />
        </Row>
        <div>
          <p className="text-sm font-medium text-white mb-1">وصف اللوحة</p>
          <p className="text-xs text-muted-foreground mb-2">النص الذي يظهر في Embed اللوحة</p>
          <textarea className={`${inputCls} resize-none`} rows={3} value={t.panelDescription} onChange={e => set("panelDescription", e.target.value)} />
        </div>
        <Row label="لون Embed اللوحة" desc="لون الشريط الجانبي للـ Embed">
          <div className="flex items-center gap-2">
            <input type="color" className="w-10 h-9 rounded-lg border border-border bg-muted/50 cursor-pointer p-0.5" value={t.panelColor} onChange={e => set("panelColor", e.target.value)} />
            <input className={`${inputCls} flex-1`} value={t.panelColor} onChange={e => set("panelColor", e.target.value)} placeholder="#5865F2" />
          </div>
        </Row>
        <Row label="نص زر التذاكر" desc="النص الذي يظهر على الزر">
          <input className={inputCls} value={t.buttonLabel} onChange={e => set("buttonLabel", e.target.value)} placeholder="فتح تذكرة" />
        </Row>
        <Row label="إيموجي الزر" desc="يظهر قبل نص الزر">
          <input className={inputCls} value={t.buttonEmoji} onChange={e => set("buttonEmoji", e.target.value)} placeholder="🎫" />
        </Row>
        <Row label="لون الزر" desc="لون زر فتح التذكرة">
          <select className={inputCls} value={t.buttonColor} onChange={e => set("buttonColor", e.target.value as TS["buttonColor"])}>
            <option value="Primary">💜 Primary — بنفسجي</option>
            <option value="Secondary">⬜ Secondary — رمادي</option>
            <option value="Success">💚 Success — أخضر</option>
            <option value="Danger">❤️ Danger — أحمر</option>
          </select>
        </Row>
        {/* Preview */}
        <div>
          <p className="text-xs text-muted-foreground mb-2">معاينة:</p>
          <div className="p-4 rounded-lg bg-[#2b2d31] border border-[#1e1f22]">
            <div className="flex items-start gap-2 mb-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-xs font-semibold text-purple-300 mb-1">RXZ Bot</p>
                <div className={`rounded-lg p-3 border-r-4`} style={{ borderColor: t.panelColor, backgroundColor: t.panelColor + "15" }}>
                  <p className="text-sm font-bold text-white">{t.panelTitle}</p>
                  <p className="text-xs text-gray-300 mt-1">{t.panelDescription}</p>
                </div>
              </div>
            </div>
            <div className={`inline-flex items-center gap-1.5 px-4 py-2 rounded text-sm font-medium ${
              t.buttonColor === "Primary" ? "bg-[#5865F2] text-white" :
              t.buttonColor === "Success" ? "bg-[#57F287] text-black" :
              t.buttonColor === "Danger" ? "bg-[#ED4245] text-white" :
              "bg-[#4e5058] text-white"
            }`}>
              <span>{t.buttonEmoji}</span> {t.buttonLabel}
            </div>
          </div>
        </div>
      </Section>

      {/* ── SECTION 3: Channels & Roles ── */}
      <Section id="channels">
        <Row label="قناة سجل التذاكر" desc="تُسجَّل فيها فتح/إغلاق التذاكر">
          <ChannelSelect guildId={guildId} value={t.logChannel || ""} onChange={v => set("logChannel", v || null)} types={[0]} placeholder="— اختر قناة —" />
        </Row>
        <Row label="قناة Transcript" desc="تُرسَل إليها نسخة المحادثة عند الإغلاق">
          <ChannelSelect guildId={guildId} value={t.transcriptChannel || ""} onChange={v => set("transcriptChannel", v || null)} types={[0]} placeholder="— اختر قناة —" />
        </Row>
        <div>
          <p className="text-sm font-medium text-white mb-1">رتب الدعم</p>
          <p className="text-xs text-muted-foreground mb-2">يمكنها رؤية وإدارة جميع التذاكر</p>
          <MultiRoleSelect guildId={guildId} value={t.supportRoles} onChange={ids => set("supportRoles", ids)} />
          <p className="text-xs text-muted-foreground mt-1">{t.supportRoles.length} رتبة مختارة</p>
        </div>
      </Section>

      {/* ── SECTION 4: Behavior ── */}
      <Section id="behavior">
        <Toggle label="إلزامية سبب الفتح" desc="يجب على العضو كتابة سبب عند فتح التذكرة" value={t.reasonRequired} onChange={v => set("reasonRequired", v)} />
        <Toggle label="إلزامية سبب الإغلاق" desc="يجب على المشرف كتابة سبب عند إغلاق التذكرة" value={t.closeReasonRequired} onChange={v => set("closeReasonRequired", v)} />
        <Toggle label="تنبيه رتب الدعم" desc="منشن رتب الدعم عند فتح أي تذكرة جديدة" value={t.pingSupport} onChange={v => set("pingSupport", v)} />
        <Toggle label="تأكيد الإغلاق" desc="طلب تأكيد قبل إغلاق التذكرة (زر تأكيد)" value={t.closeConfirmation} onChange={v => set("closeConfirmation", v)} />
        <Toggle label="DM عند الإغلاق" desc="إرسال رسالة خاصة للعضو عند إغلاق تذكرته" value={t.dmOnClose} onChange={v => set("dmOnClose", v)} />
        <Toggle label="Transcript تلقائي عند الإغلاق" desc="حفظ نسخة المحادثة تلقائياً عند كل إغلاق" value={t.transcriptOnClose} onChange={v => set("transcriptOnClose", v)} />
      </Section>

      {/* ── SECTION 5: Auto Close ── */}
      <Section id="autoclose">
        <Toggle label="إغلاق تلقائي" desc="إغلاق التذاكر غير النشطة تلقائياً" value={t.autoClose} onChange={v => set("autoClose", v)} />
        {t.autoClose && (
          <Row label="مدة الخمول (ساعات)" desc="أغلق التذكرة إذا لم يكن فيها نشاط لمدة">
            <input type="number" min={1} max={168} className={inputCls} value={t.autoCloseHours} onChange={e => set("autoCloseHours", parseInt(e.target.value) || 24)} />
          </Row>
        )}
        <div className="p-3 rounded-lg bg-orange-500/10 border border-orange-500/20 text-xs text-orange-300">
          ⚠️ الإغلاق التلقائي يُغلق التذكرة ويُرسل إشعاراً للعضو قبل الإغلاق بـ 10 دقائق.
        </div>
      </Section>

      {/* ── SECTION 6: Rating ── */}
      <Section id="rating">
        <Toggle label="تفعيل نظام التقييم ⭐" desc="يطلب من العضو تقييم الدعم (1-5 نجوم) عند إغلاق التذكرة" value={t.ratingEnabled} onChange={v => set("ratingEnabled", v)} />
        {t.ratingEnabled && (
          <Row label="قناة إرسال التقييمات" desc="تظهر فيها تقييمات الأعضاء للدعم">
            <ChannelSelect guildId={guildId} value={t.ratingChannel || ""} onChange={v => set("ratingChannel", v || null)} types={[0]} placeholder="— اختر قناة —" />
          </Row>
        )}
        {t.ratingEnabled && (
          <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-xs text-yellow-300">
            ⭐ التقييم يُرسَل للعضو في رسالة خاصة بعد إغلاق التذكرة، وتُحفظ النتيجة في قناة التقييمات.
          </div>
        )}
      </Section>

      {/* ── SECTION 7: Messages ── */}
      <Section id="messages">
        <div>
          <p className="text-sm font-medium text-white mb-1">رسالة الترحيب في التذكرة</p>
          <p className="text-xs text-muted-foreground mb-2">تظهر تلقائياً عند فتح أي تذكرة جديدة</p>
          <textarea className={`${inputCls} resize-none`} rows={4} value={t.openMessage} onChange={e => set("openMessage", e.target.value)} />
          <div className="mt-3 p-3 rounded-lg bg-[#2b2d31] border border-[#1e1f22] flex items-start gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex-shrink-0" />
            <div>
              <span className="text-xs font-semibold text-purple-300">RXZ Bot</span>
              <p className="text-sm text-gray-200 mt-0.5">{t.openMessage}</p>
            </div>
          </div>
        </div>
      </Section>

      {/* Commands guide */}
      <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/20">
        <div className="flex items-start gap-3">
          <FileText className="w-4 h-4 text-purple-300 mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="text-sm font-semibold text-purple-300 mb-2">🎫 أوامر التذاكر</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-xs text-purple-200">
              {[
                ["/ticket setup [قناة]", "إنشاء لوحة التذاكر"],
                ["/ticket close [سبب]", "إغلاق التذكرة"],
                ["/ticket add [@عضو]", "إضافة عضو"],
                ["/ticket remove [@عضو]", "إزالة عضو"],
                ["/ticket transcript", "حفظ المحادثة"],
                ["/ticket claim", "المطالبة بالتذكرة"],
              ].map(([cmd, desc]) => (
                <p key={cmd}><code className="bg-purple-900/40 px-1 rounded">{cmd}</code> — {desc}</p>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const inputCls = "w-full px-3 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-purple-500";

function Row({ label, desc, children }: { label: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 flex-wrap">
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium text-white">{label}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{desc}</div>
      </div>
      <div className="w-full sm:w-52">{children}</div>
    </div>
  );
}

function Toggle({ label, desc, value, onChange }: { label: string; desc: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div><div className="text-sm font-medium text-white">{label}</div><div className="text-xs text-muted-foreground mt-0.5">{desc}</div></div>
      <button onClick={() => onChange(!value)} className={`relative w-11 h-6 rounded-full transition-all flex-shrink-0 ${value ? "bg-purple-600" : "bg-muted"}`}>
        <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all shadow ${value ? "left-6" : "left-1"}`} />
      </button>
    </div>
  );
}
