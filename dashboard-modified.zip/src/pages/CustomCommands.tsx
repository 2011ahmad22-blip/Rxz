import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Terminal, Trash2, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type Cmd = { trigger: string; response: string };

export default function CustomCommands() {
  const [cmds, setCmds] = useState<Cmd[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState<string | null>(null);
  const { toast } = useToast();

  const load = () => {
    setLoading(true);
    api.getCustomCommands().then(setCmds).catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const del = async (trigger: string) => {
    setDeleting(trigger);
    try {
      await api.deleteCustomCommand(trigger);
      setCmds(prev => prev.filter(c => c.trigger !== trigger));
      toast({ title: "✅ تم الحذف", description: `تم حذف الأمر "${trigger}".` });
    } catch {
      toast({ title: "خطأ", description: "فشل في الحذف.", variant: "destructive" });
    } finally { setDeleting(null); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">الأوامر المخصصة</h2>
          <p className="text-muted-foreground text-sm mt-0.5">إدارة الأوامر الخاصة بسيرفرك</p>
        </div>
        <button onClick={load} className="flex items-center gap-2 px-3 py-2 bg-muted hover:bg-muted/70 text-white rounded-lg text-sm transition-colors">
          <RefreshCw className="w-4 h-4" />
          تحديث
        </button>
      </div>

      <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/20">
        <div className="flex items-start gap-3">
          <Terminal className="w-4 h-4 text-purple-300 mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="text-sm font-semibold text-purple-300 mb-1">إضافة أمر جديد من ديسكورد</h4>
            <p className="text-xs text-purple-200">
              <code className="bg-purple-900/40 px-1 rounded">/customcmd add [trigger] [response]</code>
            </p>
            <p className="text-xs text-purple-200 mt-1">الاستخدام: اكتب <code className="bg-purple-900/40 px-1 rounded">!trigger</code> في أي قناة</p>
          </div>
        </div>
      </div>

      <div className="stat-card rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Terminal className="w-4 h-4 text-green-400" />
          <h3 className="font-semibold text-white">الأوامر المخصصة</h3>
          <span className="text-xs text-muted-foreground mr-auto">{cmds.length} أمر</span>
        </div>

        {loading ? (
          <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="h-16 bg-muted/30 rounded-lg animate-pulse" />)}</div>
        ) : cmds.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Terminal className="w-10 h-10 mx-auto mb-3 opacity-20" />
            <p className="text-sm">لا توجد أوامر مخصصة بعد</p>
            <p className="text-xs mt-1">استخدم <code className="text-purple-300">/customcmd add</code> في ديسكورد</p>
          </div>
        ) : (
          <div className="space-y-2">
            {cmds.map(cmd => (
              <div key={cmd.trigger} className="flex items-start gap-3 p-4 rounded-lg bg-muted/20 hover:bg-muted/30 transition-colors group">
                <div className="flex-1 min-w-0">
                  <code className="text-sm font-mono font-bold text-purple-300">!{cmd.trigger}</code>
                  <p className="text-sm text-muted-foreground mt-0.5 truncate">{cmd.response}</p>
                </div>
                <button
                  onClick={() => del(cmd.trigger)}
                  disabled={deleting === cmd.trigger}
                  className="opacity-0 group-hover:opacity-100 p-1.5 text-muted-foreground hover:text-red-400 hover:bg-red-400/10 rounded transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="stat-card rounded-xl p-5">
        <h3 className="font-semibold text-white mb-3">متغيرات الرد المتاحة</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          {[["{user}", "تاغ العضو (@اسم)"], ["{username}", "اسم العضو فقط"], ["{server}", "اسم السيرفر"], ["{memberCount}", "عدد الأعضاء الكلي"]].map(([v, d]) => (
            <div key={v} className="flex gap-2 p-2 rounded bg-muted/20">
              <code className="text-purple-300 font-mono flex-shrink-0">{v}</code>
              <span className="text-muted-foreground">{d}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
