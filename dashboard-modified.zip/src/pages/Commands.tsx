import { useState } from "react";
import { Terminal, Shield, Info, Star, Gift, Ticket, Zap, Search, ChevronDown } from "lucide-react";

type Command = {
  name: string;
  description: string;
  usage: string;
  permission?: string;
  aliases?: string[];
  slash?: boolean;
  prefix?: boolean;
};

type Category = {
  id: string;
  label: string;
  icon: React.ReactNode;
  color: string;
  gradient: string;
  commands: Command[];
};

const CATEGORIES: Category[] = [
  {
    id: "moderation",
    label: "الإشراف",
    icon: <Shield className="w-4 h-4" />,
    color: "text-red-400",
    gradient: "from-red-600/20 to-red-800/10 border-red-500/20",
    commands: [
      { name: "ban", description: "حظر عضو من السيرفر مع سبب", usage: "/ban [@عضو] [سبب] [أيام]", permission: "Ban Members", slash: true, prefix: true },
      { name: "unban", description: "رفع الحظر عن عضو باستخدام ID", usage: "/unban [ID] [سبب]", permission: "Ban Members", slash: true, prefix: true },
      { name: "kick", description: "طرد عضو من السيرفر", usage: "/kick [@عضو] [سبب]", permission: "Kick Members", slash: true, prefix: true },
      { name: "mute", description: "كتم عضو ومنعه من الكتابة", usage: "/mute [@عضو] [سبب]", permission: "Manage Roles", slash: true, prefix: true },
      { name: "unmute", description: "رفع الكتم عن عضو", usage: "/unmute [@عضو]", permission: "Manage Roles", slash: true, prefix: true },
      { name: "timeout", description: "تايم أوت مؤقت لعضو", usage: "/timeout [@عضو] [دقائق] [سبب]", permission: "Moderate Members", slash: true, prefix: true },
      { name: "untimeout", description: "رفع التايم أوت عن عضو", usage: "/untimeout [@عضو]", permission: "Moderate Members", slash: true, prefix: true },
      { name: "warn", description: "إعطاء تحذير لعضو مع سبب", usage: "/warn [@عضو] [سبب]", permission: "Manage Messages", slash: true, prefix: true },
      { name: "warnings", description: "عرض قائمة تحذيرات عضو", usage: "/warnings [@عضو]", permission: "Manage Messages", slash: true, prefix: true },
      { name: "clearwarns", description: "مسح كل تحذيرات عضو", usage: "/clearwarns [@عضو]", permission: "Manage Messages", slash: true, prefix: true },
      { name: "softban", description: "حذف رسائل العضو ثم رفع الحظر فوراً", usage: "/softban [@عضو] [أيام] [سبب]", permission: "Ban Members", slash: true, prefix: true },
      { name: "tempban", description: "حظر مؤقت لعضو لمدة محددة", usage: "/tempban [@عضو] [أيام] [سبب]", permission: "Ban Members", slash: true },
      { name: "nick", description: "تغيير لقب عضو في السيرفر", usage: "/nick [@عضو] [اللقب الجديد]", permission: "Manage Nicknames", slash: true, prefix: true },
      { name: "clear", description: "حذف عدد من الرسائل دفعة واحدة", usage: "/clear [العدد]", permission: "Manage Messages", slash: true, prefix: true },
      { name: "role", description: "إضافة أو إزالة رتبة من عضو", usage: "/role [add/remove] [@عضو] [@رتبة]", permission: "Manage Roles", slash: true, prefix: true },
      { name: "lock", description: "قفل القناة ومنع الكتابة فيها", usage: "/lock [قناة] [سبب]", permission: "Manage Channels", slash: true, prefix: true },
      { name: "unlock", description: "فتح القناة والسماح بالكتابة مجدداً", usage: "/unlock [قناة]", permission: "Manage Channels", slash: true, prefix: true },
      { name: "slowmode", description: "تفعيل أو إيقاف السلو مود في القناة", usage: "/slowmode [ثواني]", permission: "Manage Channels", slash: true, prefix: true },
    ],
  },
  {
    id: "info",
    label: "المعلومات والأدوات",
    icon: <Info className="w-4 h-4" />,
    color: "text-blue-400",
    gradient: "from-blue-600/20 to-blue-800/10 border-blue-500/20",
    commands: [
      { name: "ping", description: "فحص سرعة استجابة البوت وجودة الاتصال", usage: "/ping", slash: true, prefix: true },
      { name: "botinfo", description: "معلومات شاملة عن البوت", usage: "/botinfo", slash: true, prefix: true },
      { name: "userinfo", description: "معلومات تفصيلية عن عضو في السيرفر", usage: "/userinfo [@عضو]", slash: true, prefix: true },
      { name: "serverinfo", description: "معلومات تفصيلية عن السيرفر الحالي", usage: "/serverinfo", slash: true, prefix: true },
      { name: "avatar", description: "عرض صورة البروفايل بجودة عالية", usage: "/avatar [@عضو]", slash: true, prefix: true },
      { name: "embed", description: "إنشاء رسالة embed منسقة", usage: "/embed [العنوان] [النص] [اللون]", permission: "Manage Messages", slash: true },
      { name: "help", description: "عرض قائمة الأوامر والمساعدة", usage: "/help [أمر]", slash: true, prefix: true },
    ],
  },
  {
    id: "levels",
    label: "المستويات والـ XP",
    icon: <Star className="w-4 h-4" />,
    color: "text-purple-400",
    gradient: "from-purple-600/20 to-purple-800/10 border-purple-500/20",
    commands: [
      { name: "level", description: "عرض مستواك الحالي وXP في السيرفر", usage: "/level [@عضو]", slash: true, prefix: true },
      { name: "leaderboard", description: "لوحة المتصدرين بأعلى XP في السيرفر", usage: "/leaderboard", slash: true, prefix: true },
    ],
  },
  {
    id: "giveaway",
    label: "السحوبات",
    icon: <Gift className="w-4 h-4" />,
    color: "text-pink-400",
    gradient: "from-pink-600/20 to-pink-800/10 border-pink-500/20",
    commands: [
      { name: "giveaway start", description: "بدء سحب جديد بجائزة ومدة محددة", usage: "/giveaway start [قناة] [مدة بالدقائق] [عدد الفائزين] [الجائزة]", permission: "Manage Guild", slash: true },
      { name: "giveaway end", description: "إنهاء سحب قبل انتهاء وقته", usage: "/giveaway end [message_id]", permission: "Manage Guild", slash: true },
      { name: "giveaway reroll", description: "إعادة السحب واختيار فائز جديد", usage: "/giveaway reroll [message_id]", permission: "Manage Guild", slash: true },
      { name: "giveaway list", description: "عرض قائمة السحوبات النشطة", usage: "/giveaway list", slash: true },
    ],
  },
  {
    id: "tickets",
    label: "نظام التذاكر",
    icon: <Ticket className="w-4 h-4" />,
    color: "text-yellow-400",
    gradient: "from-yellow-600/20 to-yellow-800/10 border-yellow-500/20",
    commands: [
      { name: "ticket setup", description: "إنشاء لوحة تذاكر في قناة محددة", usage: "/ticket setup [قناة]", permission: "Manage Guild", slash: true },
      { name: "ticket close", description: "إغلاق التذكرة الحالية وأرشفتها", usage: "/ticket close [سبب]", slash: true },
      { name: "ticket add", description: "إضافة عضو إلى التذكرة الحالية", usage: "/ticket add [@عضو]", permission: "Manage Channels", slash: true },
      { name: "ticket remove", description: "إزالة عضو من التذكرة الحالية", usage: "/ticket remove [@عضو]", permission: "Manage Channels", slash: true },
      { name: "ticket transcript", description: "حفظ نسخة من محادثة التذكرة", usage: "/ticket transcript", permission: "Manage Channels", slash: true },
      { name: "ticket claim", description: "مطالبة بالمسؤولية عن التذكرة", usage: "/ticket claim", permission: "Support Role", slash: true },
    ],
  },
  {
    id: "custom",
    label: "الأوامر المخصصة",
    icon: <Terminal className="w-4 h-4" />,
    color: "text-green-400",
    gradient: "from-green-600/20 to-green-800/10 border-green-500/20",
    commands: [
      { name: "customcmd add", description: "إضافة أمر مخصص برد تلقائي", usage: "/customcmd add [الأمر] [الرد]", permission: "Manage Guild", slash: true },
      { name: "customcmd remove", description: "حذف أمر مخصص", usage: "/customcmd remove [الأمر]", permission: "Manage Guild", slash: true },
      { name: "customcmd list", description: "عرض قائمة الأوامر المخصصة", usage: "/customcmd list", slash: true },
      { name: "alias add", description: "إضافة اختصار لأمر موجود", usage: "/alias add [الاختصار] [الأمر الأصلي]", permission: "Manage Guild", slash: true },
      { name: "alias remove", description: "حذف اختصار", usage: "/alias remove [الاختصار]", permission: "Manage Guild", slash: true },
      { name: "alias list", description: "عرض قائمة الاختصارات", usage: "/alias list", slash: true },
      { name: "autorole add", description: "إضافة رتبة تلقائية للأعضاء الجدد", usage: "/autorole add [@رتبة]", permission: "Manage Guild", slash: true },
      { name: "autorole remove", description: "إزالة رتبة تلقائية", usage: "/autorole remove [@رتبة]", permission: "Manage Guild", slash: true },
      { name: "setup", description: "إعداد البوت وتهيئة الإعدادات الأساسية", usage: "/setup", permission: "Administrator", slash: true },
    ],
  },
];

export default function Commands() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [expandedCmd, setExpandedCmd] = useState<string | null>(null);

  const totalCmds = CATEGORIES.reduce((s, c) => s + c.commands.length, 0);

  const filtered = CATEGORIES.map(cat => ({
    ...cat,
    commands: cat.commands.filter(cmd =>
      cmd.name.includes(search.toLowerCase()) ||
      cmd.description.includes(search) ||
      cmd.usage.toLowerCase().includes(search.toLowerCase())
    ),
  })).filter(cat => (activeCategory ? cat.id === activeCategory : true) && cat.commands.length > 0);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl p-6 bg-gradient-to-br from-purple-900/40 via-blue-900/20 to-transparent border border-purple-500/20">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-blue-600/5" />
        <div className="relative">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center shadow-lg shadow-purple-500/25">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">مرجع الأوامر</h2>
              <p className="text-sm text-purple-300">{totalCmds} أمر في {CATEGORIES.length} تصنيف</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2 mt-3">
            <span className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-purple-400" /> Slash أوامر
            </span>
            <span className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400" /> Prefix أوامر
            </span>
          </div>
        </div>
      </div>

      {/* Search + filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <input
            className="w-full pr-10 pl-4 py-2.5 bg-muted/40 border border-border rounded-xl text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-purple-500 focus:border-purple-500/50"
            placeholder="ابحث عن أمر…"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setActiveCategory(null)}
            className={`px-3 py-2 rounded-xl text-xs font-medium transition-all border ${
              !activeCategory ? "bg-purple-600 border-purple-500 text-white shadow-md shadow-purple-500/20" : "bg-muted/30 border-border text-muted-foreground hover:text-white hover:border-purple-500/30"
            }`}
          >الكل ({totalCmds})</button>
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(activeCategory === cat.id ? null : cat.id)}
              className={`px-3 py-2 rounded-xl text-xs font-medium transition-all border flex items-center gap-1.5 ${
                activeCategory === cat.id ? "bg-purple-600 border-purple-500 text-white shadow-md shadow-purple-500/20" : "bg-muted/30 border-border text-muted-foreground hover:text-white hover:border-purple-500/30"
              }`}
            >
              <span className={cat.color}>{cat.icon}</span>
              {cat.label} ({cat.commands.length})
            </button>
          ))}
        </div>
      </div>

      {/* Command categories */}
      {filtered.map(cat => (
        <div key={cat.id} className="space-y-2">
          <div className={`flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-gradient-to-r ${cat.gradient} border`}>
            <span className={cat.color}>{cat.icon}</span>
            <span className="font-semibold text-white text-sm">{cat.label}</span>
            <span className="mr-auto text-xs text-muted-foreground">{cat.commands.length} أوامر</span>
          </div>

          <div className="grid gap-2">
            {cat.commands.map(cmd => {
              const key = `${cat.id}-${cmd.name}`;
              const open = expandedCmd === key;
              return (
                <div
                  key={cmd.name}
                  className={`rounded-xl border transition-all cursor-pointer ${
                    open ? "bg-muted/20 border-purple-500/30" : "bg-muted/10 border-border hover:border-purple-500/20 hover:bg-muted/15"
                  }`}
                  onClick={() => setExpandedCmd(open ? null : key)}
                >
                  <div className="flex items-center gap-3 px-4 py-3">
                    {/* Command badges */}
                    <div className="flex items-center gap-1 flex-shrink-0">
                      {cmd.slash && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono font-bold">/</span>
                      )}
                      {cmd.prefix && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono font-bold">!</span>
                      )}
                    </div>
                    <code className="text-sm font-mono font-semibold text-white">{cmd.name}</code>
                    <span className="text-xs text-muted-foreground flex-1 min-w-0 truncate">{cmd.description}</span>
                    {cmd.permission && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-orange-500/15 text-orange-400 border border-orange-500/20 flex-shrink-0 hidden sm:block">
                        🔒 {cmd.permission}
                      </span>
                    )}
                    <ChevronDown className={`w-4 h-4 text-muted-foreground flex-shrink-0 transition-transform ${open ? "rotate-180" : ""}`} />
                  </div>

                  {open && (
                    <div className="px-4 pb-4 pt-1 space-y-3 border-t border-border">
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">الوصف</p>
                        <p className="text-sm text-white">{cmd.description}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">الاستخدام</p>
                        <code className="text-sm text-purple-300 bg-purple-500/10 px-3 py-1.5 rounded-lg block font-mono">{cmd.usage}</code>
                      </div>
                      <div className="flex gap-4 flex-wrap">
                        {cmd.permission && (
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">الصلاحية المطلوبة</p>
                            <span className="text-xs px-2.5 py-1 rounded-full bg-orange-500/15 text-orange-400 border border-orange-500/20">
                              🔒 {cmd.permission}
                            </span>
                          </div>
                        )}
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">نوع الأمر</p>
                          <div className="flex gap-1.5">
                            {cmd.slash && <span className="text-xs px-2.5 py-1 rounded-full bg-purple-500/15 text-purple-300 border border-purple-500/20">Slash /</span>}
                            {cmd.prefix && <span className="text-xs px-2.5 py-1 rounded-full bg-blue-500/15 text-blue-300 border border-blue-500/20">Prefix !</span>}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ))}

      {filtered.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <Terminal className="w-12 h-12 mx-auto mb-3 opacity-20" />
          <p className="text-sm">لم يتم العثور على أوامر مطابقة لـ "{search}"</p>
        </div>
      )}
    </div>
  );
}
