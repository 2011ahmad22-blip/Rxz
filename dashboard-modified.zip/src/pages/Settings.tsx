import { useEffect, useState } from "react";
import { api, BotConfig, BotStatus } from "@/lib/api";
import { Settings as SettingsIcon, Save, Key, RefreshCw, CheckCircle2, XCircle, Bot, Wifi, Eye, EyeOff, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [status, setStatus] = useState<BotStatus | null>(null);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [newToken, setNewToken] = useState("");
  const [showToken, setShowToken] = useState(false);
  const [updatingToken, setUpdatingToken] = useState(false);
  const { toast } = useToast();

  const loadStatus = () => {
    setRefreshing(true);
    api.getStatus().then(setStatus).catch(() => {}).finally(() => setRefreshing(false));
  };

  useEffect(() => {
    api.getConfig().then(setConfig).catch(() => {});
    loadStatus();
  }, []);

  const save = async () => {
    if (!config) return;
    setSaving(true);
    try {
      await api.updateConfig({ prefix: config.prefix });
      toast({ title: "✅ تم الحفظ", description: "تم تحديث الإعدادات بنجاح." });
    } catch {
      toast({ title: "خطأ", description: "فشل في الحفظ.", variant: "destructive" });
    } finally { setSaving(false); }
  };

  const handleTokenUpdate = async () => {
    if (!newToken.trim()) return;
    setUpdatingToken(true);
    try {
      const result = await api.updateToken(newToken.trim());
      toast({ title: "✅ تم التحديث", description: result.message });
      setNewToken("");
      setTimeout(loadStatus, 3000);
    } catch {
      toast({ title: "خطأ", description: "فشل في تحديث التوكن — تحقق من صحته.", variant: "destructive" });
    } finally { setUpdatingToken(false); }
  };

  const envVars = [
    { name: "DISCORD_TOKEN", desc: "توكن البوت من Discord Developer Portal", required: true, set: status?.hasToken },
    { name: "DISCORD_CLIENT_ID", desc: "Application ID من Discord Developer Portal", required: true, set: status?.hasClientId },
    { name: "DISCORD_GUILD_ID", desc: "ID السيرفر لتسجيل أوامر Slash بسرعة (اختياري)", required: false, set: undefined },
    { name: "DASHBOARD_API_KEY", desc: "مفتاح تأمين API الداشبورد (الافتراضي: rxz-dashboard-key)", required: false, set: undefined },
  ];

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">الإعدادات</h2>
          <p className="text-muted-foreground text-sm mt-0.5">حالة البوت ومتغيرات البيئة</p>
        </div>
        <button onClick={save} disabled={saving || !config} className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium text-sm transition-colors disabled:opacity-50 shadow-lg shadow-purple-500/20">
          <Save className="w-4 h-4" />
          {saving ? "جاري الحفظ…" : "حفظ"}
        </button>
      </div>

      {/* Bot live status */}
      <div className={`rounded-xl p-5 border ${status?.online ? "bg-green-500/5 border-green-500/30" : "bg-muted/10 border-border"}`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Wifi className="w-4 h-4 text-purple-400" />
            <h3 className="font-semibold text-white">حالة البوت الآن</h3>
          </div>
          <button onClick={loadStatus} disabled={refreshing} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-white transition-colors disabled:opacity-50">
            <RefreshCw className={`w-4 h-4 ${refreshing ? "animate-spin" : ""}`} />
          </button>
        </div>
        {status ? (
          <div className="flex items-center gap-4 flex-wrap">
            {status.botAvatar
              ? <img src={status.botAvatar} alt="bot" className="w-14 h-14 rounded-full ring-2 ring-purple-500/30 shadow-lg" />
              : <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center shadow-lg"><Bot className="w-7 h-7 text-white" /></div>
            }
            <div className="flex-1">
              <p className="font-bold text-white text-lg">{status.botName ?? "غير متصل"}</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <div className={`w-2 h-2 rounded-full ${status.online ? "bg-green-500 animate-pulse" : "bg-red-500"}`} />
                <span className={`text-sm font-medium ${status.online ? "text-green-400" : "text-red-400"}`}>
                  {status.online ? "متصل ✅" : "غير متصل ❌"}
                </span>
              </div>
            </div>
            <div className="text-center px-4 py-2 rounded-xl bg-purple-500/10 border border-purple-500/20">
              <p className="text-2xl font-bold text-white">{status.guilds}</p>
              <p className="text-xs text-muted-foreground">سيرفر</p>
            </div>
          </div>
        ) : (
          <div className="h-16 bg-muted/30 rounded-lg animate-pulse" />
        )}
      </div>

      {/* Token update */}
      <div className="stat-card rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Zap className="w-4 h-4 text-yellow-400" />
          <h3 className="font-semibold text-white">تحديث التوكن</h3>
          <span className="text-xs bg-yellow-500/20 text-yellow-400 px-2 py-0.5 rounded-full mr-auto">مؤقت — يُعاد عند إعادة التشغيل</span>
        </div>
        <p className="text-xs text-muted-foreground mb-3">
          أدخل التوكن الجديد لإعادة تشغيل البوت فوراً بدون إعادة تشغيل السيرفر.
          لحفظه بشكل دائم أضفه في <code className="bg-muted px-1 rounded">DISCORD_TOKEN</code> بالـ Secrets.
        </p>
        <div className="flex gap-2">
          <div className="relative flex-1">
            <input
              type={showToken ? "text" : "password"}
              className="w-full px-3 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-yellow-500/50 focus:border-yellow-500/30 pr-10"
              placeholder="أدخل التوكن الجديد…"
              value={newToken}
              onChange={e => setNewToken(e.target.value)}
              dir="ltr"
            />
            <button
              onClick={() => setShowToken(!showToken)}
              className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-white transition-colors"
            >
              {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <button
            onClick={handleTokenUpdate}
            disabled={updatingToken || !newToken.trim()}
            className="flex items-center gap-2 px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg font-medium text-sm transition-colors disabled:opacity-50 whitespace-nowrap"
          >
            <Zap className="w-4 h-4" />
            {updatingToken ? "جاري التحديث…" : "تحديث"}
          </button>
        </div>
      </div>

      {/* Env vars */}
      <div className="stat-card rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Key className="w-4 h-4 text-yellow-400" />
          <h3 className="font-semibold text-white">متغيرات البيئة</h3>
          <span className="text-xs text-muted-foreground mr-auto">أضفها في Secrets (🔒 بالشريط الجانبي)</span>
        </div>
        <div className="space-y-3">
          {envVars.map(({ name, desc, required, set }) => {
            const isSet = set === true;
            const isNotSet = set === false;
            return (
              <div key={name} className={`p-4 rounded-xl border transition-colors ${isSet ? "bg-green-500/5 border-green-500/30" : isNotSet ? "bg-red-500/5 border-red-500/30" : "bg-muted/10 border-border"}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <code className={`text-sm font-mono font-bold ${isSet ? "text-green-300" : isNotSet ? "text-red-300" : required ? "text-yellow-300" : "text-blue-300"}`}>{name}</code>
                      {required && !isSet && <span className="text-xs bg-red-500/20 text-red-400 px-1.5 py-0.5 rounded">مطلوب</span>}
                      {!required && <span className="text-xs bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded">اختياري</span>}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{desc}</p>
                  </div>
                  {isSet && <div className="flex items-center gap-1.5 flex-shrink-0"><CheckCircle2 className="w-5 h-5 text-green-400" /><span className="text-xs text-green-400 font-medium">تم الإضافة</span></div>}
                  {isNotSet && <div className="flex items-center gap-1.5 flex-shrink-0"><XCircle className="w-5 h-5 text-red-400" /><span className="text-xs text-red-400 font-medium">غير موجود</span></div>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Prefix */}
      <div className="stat-card rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-2 mb-1">
          <SettingsIcon className="w-4 h-4 text-purple-400" />
          <h3 className="font-semibold text-white">إعدادات البوت</h3>
        </div>
        {config ? (
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <div className="text-sm font-medium text-white">البريفيكس (Prefix)</div>
              <div className="text-xs text-muted-foreground mt-0.5">رمز الأوامر النصية (مثال: ! أو .)</div>
            </div>
            <input
              className="w-24 px-3 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white text-center focus:outline-none focus:ring-1 focus:ring-purple-500"
              value={config.prefix}
              onChange={e => setConfig({ ...config, prefix: e.target.value })}
              placeholder="!"
            />
          </div>
        ) : <div className="h-12 bg-muted/30 rounded-lg animate-pulse" />}
      </div>

      {/* How-to guide */}
      <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20">
        <div className="flex items-start gap-3">
          <RefreshCw className="w-4 h-4 text-green-300 mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="text-sm font-semibold text-green-300 mb-2">خطوات تشغيل البوت</h4>
            <ol className="text-xs text-green-200 space-y-1.5 list-decimal list-inside">
              <li>افتح <strong>Secrets</strong> — أيقونة القفل 🔒 في الشريط الجانبي</li>
              <li>أضف <code className="bg-green-900/40 px-1 rounded">DISCORD_TOKEN</code> بتوكن البوت</li>
              <li>أضف <code className="bg-green-900/40 px-1 rounded">DISCORD_CLIENT_ID</code> بـ Application ID</li>
              <li>أعد تشغيل <strong>API Server</strong> من Workflows ✅</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}
