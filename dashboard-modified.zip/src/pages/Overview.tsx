import { useEffect, useState } from "react";
import { api, BotStats, BotStatus } from "@/lib/api";
import {
  AlertTriangle, VolumeX, Star, Gift, Terminal, GitMerge,
  TrendingUp, Activity, RefreshCw, Shield, Zap, Bot, Ticket, Crown,
} from "lucide-react";

export default function Overview() {
  const [stats, setStats] = useState<BotStats | null>(null);
  const [status, setStatus] = useState<BotStatus | null>(null);
  const [leaderboard, setLeaderboard] = useState<Array<{ id: string; xp: number; level: number }>>([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    Promise.all([api.getStats(), api.getLeaderboard(), api.getStatus()])
      .then(([s, lb, st]) => { setStats(s); setLeaderboard(lb.slice(0, 5)); setStatus(st); })
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const statCards = stats ? [
    { label: "إجمالي التحذيرات", value: stats.totalWarnings, icon: AlertTriangle, color: "from-orange-500 to-orange-700", glow: "shadow-orange-500/20", sub: "منذ البداية" },
    { label: "الأعضاء المكتومون", value: stats.totalMuted, icon: VolumeX, color: "from-red-500 to-red-700", glow: "shadow-red-500/20", sub: "حالياً" },
    { label: "أعضاء XP", value: stats.totalXpUsers, icon: Star, color: "from-purple-500 to-purple-700", glow: "shadow-purple-500/20", sub: "في اللوحة" },
    { label: "السحوبات النشطة", value: stats.activeGiveaways, icon: Gift, color: "from-pink-500 to-pink-700", glow: "shadow-pink-500/20", sub: "تشتغل الآن" },
    { label: "الأوامر المخصصة", value: stats.customCmds, icon: Terminal, color: "from-green-500 to-green-700", glow: "shadow-green-500/20", sub: "مضافة" },
    { label: "الاختصارات", value: stats.aliases, icon: GitMerge, color: "from-blue-500 to-blue-700", glow: "shadow-blue-500/20", sub: "مختصر" },
  ] : [];

  return (
    <div className="space-y-6">
      {/* Hero header */}
      <div className="relative overflow-hidden rounded-2xl p-6 bg-gradient-to-br from-purple-900/50 via-[#0d0f1a] to-blue-900/30 border border-purple-500/20">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(139,92,246,0.15),_transparent_60%)]" />
        <div className="absolute top-0 left-0 w-64 h-64 bg-blue-600/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="relative flex items-start justify-between gap-4 flex-wrap">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Crown className="w-4 h-4 text-yellow-400" />
              <span className="text-xs text-yellow-400 font-medium">النسخة الاحترافية v2.0</span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-1">لوحة تحكم RXZ Bot</h2>
            <p className="text-sm text-purple-300/80">بوت ديسكورد احترافي متكامل — إشراف، حماية، ترفيه</p>
          </div>
          <div className="flex items-center gap-3">
            {status?.botAvatar && <img src={status.botAvatar} className="w-12 h-12 rounded-full ring-2 ring-purple-500/50" alt="bot" />}
            <div>
              <p className="font-bold text-white text-sm">{status?.botName ?? "—"}</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <div className={`w-2 h-2 rounded-full ${status?.online ? "bg-green-500 animate-pulse" : "bg-red-500"}`} />
                <span className={`text-xs ${status?.online ? "text-green-400" : "text-red-400"}`}>
                  {status?.online ? "متصل" : "غير متصل"}
                </span>
                {status?.guilds && <span className="text-xs text-muted-foreground">· {status.guilds} سيرفر</span>}
              </div>
            </div>
          </div>
        </div>
        <div className="relative mt-4 flex items-center justify-between">
          <div className="flex gap-2 flex-wrap">
            {[["32", "أمر"], ["10", "صفحة"], ["∞", "إمكانيات"]].map(([v, l]) => (
              <div key={l} className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-center">
                <span className="text-sm font-bold text-white">{v}</span>
                <span className="text-xs text-muted-foreground mr-1">{l}</span>
              </div>
            ))}
          </div>
          <button onClick={load} disabled={loading} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-sm text-muted-foreground hover:text-white transition-colors disabled:opacity-50">
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
            تحديث
          </button>
        </div>
      </div>

      {/* Stat cards */}
      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
          {[...Array(6)].map((_, i) => <div key={i} className="stat-card rounded-xl p-4 h-24 animate-pulse" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
          {statCards.map(({ label, value, icon: Icon, color, glow, sub }) => (
            <div key={label} className="stat-card rounded-xl p-4 glow-purple-hover group transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center shadow-lg ${glow}`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <TrendingUp className="w-3.5 h-3.5 text-muted-foreground/50 group-hover:text-purple-400 transition-colors" />
              </div>
              <div className="text-2xl font-bold text-white tabular-nums">{value}</div>
              <div className="text-xs font-medium text-muted-foreground mt-0.5">{label}</div>
              <div className="text-xs text-muted-foreground/50">{sub}</div>
            </div>
          ))}
        </div>
      )}

      {/* Bottom row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Leaderboard */}
        <div className="lg:col-span-2 stat-card rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Star className="w-4 h-4 text-purple-400" />
            <h3 className="font-semibold text-white">لوحة المتصدرين XP</h3>
            <span className="text-xs text-muted-foreground mr-auto">أفضل 5</span>
          </div>
          {leaderboard.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <Star className="w-10 h-10 mx-auto mb-2 opacity-20" />
              <p className="text-sm">لا يوجد XP بعد</p>
              <p className="text-xs mt-1 opacity-60">الأعضاء يكسبون XP بالتحدث في السيرفر</p>
            </div>
          ) : (
            <div className="space-y-2">
              {leaderboard.map((u, i) => (
                <div key={u.id} className="flex items-center gap-3 p-3 rounded-xl bg-muted/20 hover:bg-muted/30 transition-colors">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0 shadow-md ${
                    i === 0 ? "bg-gradient-to-br from-yellow-400 to-yellow-600 text-black" :
                    i === 1 ? "bg-gradient-to-br from-gray-300 to-gray-500 text-black" :
                    i === 2 ? "bg-gradient-to-br from-orange-400 to-orange-700 text-white" :
                    "bg-muted text-muted-foreground"
                  }`}>{i === 0 ? "👑" : i + 1}</div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-white truncate font-mono">…{u.id.slice(-8)}</div>
                    <div className="w-full bg-muted rounded-full h-1.5 mt-1.5">
                      <div className="bg-gradient-to-r from-purple-500 to-blue-500 h-1.5 rounded-full transition-all" style={{ width: `${Math.min(100, (u.xp / (leaderboard[0]?.xp || 1)) * 100)}%` }} />
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-xs font-bold text-purple-300">Lv.{u.level}</div>
                    <div className="text-xs text-muted-foreground">{u.xp.toLocaleString()} XP</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick stats */}
        <div className="stat-card rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-4 h-4 text-purple-400" />
            <h3 className="font-semibold text-white">إحصائيات سريعة</h3>
          </div>
          <div className="space-y-3">
            {[
              { label: "البريفيكس", value: stats?.prefix || "—", icon: "⌨️" },
              { label: "سحوبات نشطة", value: String(stats?.activeGiveaways ?? "—"), icon: "🎁" },
              { label: "أوامر مخصصة", value: String(stats?.customCmds ?? "—"), icon: "⚡" },
              { label: "اختصارات", value: String(stats?.aliases ?? "—"), icon: "🔗" },
              { label: "أعضاء XP", value: String(stats?.totalXpUsers ?? "—"), icon: "⭐" },
              { label: "إجمالي الأوامر", value: "32", icon: "🤖" },
            ].map(({ label, value, icon }) => (
              <div key={label} className="flex items-center gap-2.5 py-1.5 border-b border-border/50 last:border-0">
                <span className="text-base">{icon}</span>
                <span className="text-sm text-muted-foreground flex-1">{label}</span>
                <span className="text-sm font-bold text-white tabular-nums">{value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features grid */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Zap className="w-4 h-4 text-purple-400" />
          <h3 className="font-semibold text-white">مميزات النسخة الاحترافية</h3>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { icon: Shield, label: "الإشراف الكامل", desc: "18 أمر إشراف متكامل", color: "from-red-500/20 to-red-700/10 border-red-500/20", ic: "text-red-400" },
            { icon: Zap, label: "الحماية الشاملة", desc: "ريد، سبام، شتائم، روابط، بوتات", color: "from-yellow-500/20 to-yellow-700/10 border-yellow-500/20", ic: "text-yellow-400" },
            { icon: Ticket, label: "نظام التذاكر", desc: "تقييم، claim، transcript، DM", color: "from-purple-500/20 to-purple-700/10 border-purple-500/20", ic: "text-purple-400" },
            { icon: Star, label: "المستويات XP", desc: "XP تلقائي ولوحة متصدرين", color: "from-blue-500/20 to-blue-700/10 border-blue-500/20", ic: "text-blue-400" },
            { icon: Gift, label: "السحوبات", desc: "سحوبات تلقائية متعددة", color: "from-pink-500/20 to-pink-700/10 border-pink-500/20", ic: "text-pink-400" },
            { icon: Terminal, label: "أوامر مخصصة", desc: "أنشئ ردودك وأوامرك", color: "from-green-500/20 to-green-700/10 border-green-500/20", ic: "text-green-400" },
            { icon: Bot, label: "مرجع الأوامر", desc: "32 أمر موثق بالتفصيل", color: "from-orange-500/20 to-orange-700/10 border-orange-500/20", ic: "text-orange-400" },
            { icon: Activity, label: "لوحة تحكم مباشرة", desc: "تحكم كامل من الموقع", color: "from-teal-500/20 to-teal-700/10 border-teal-500/20", ic: "text-teal-400" },
          ].map(({ icon: Icon, label, desc, color, ic }) => (
            <div key={label} className={`rounded-xl p-4 bg-gradient-to-br ${color} border glow-purple-hover transition-all group`}>
              <div className={`w-8 h-8 rounded-lg bg-gradient-to-br from-white/10 to-transparent flex items-center justify-center mb-3`}>
                <Icon className={`w-4 h-4 ${ic}`} />
              </div>
              <div className="text-sm font-semibold text-white">{label}</div>
              <div className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
