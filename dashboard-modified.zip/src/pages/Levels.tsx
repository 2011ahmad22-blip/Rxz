import { useEffect, useState } from "react";
import { api, BotConfig } from "@/lib/api";
import { Star, Save, Trophy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Levels() {
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [leaderboard, setLeaderboard] = useState<Array<{ id: string; xp: number; level: number }>>([]);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    Promise.all([api.getConfig(), api.getLeaderboard()])
      .then(([c, lb]) => { setConfig(c); setLeaderboard(lb); })
      .catch(() => {});
  }, []);

  const save = async () => {
    if (!config) return;
    setSaving(true);
    try {
      await api.updateConfig({ levelSettings: config.levelSettings });
      toast({ title: "✅ تم الحفظ", description: "تم تحديث إعدادات نظام XP." });
    } catch {
      toast({ title: "خطأ", description: "فشل في الحفظ.", variant: "destructive" });
    } finally { setSaving(false); }
  };

  const setL = (key: keyof BotConfig["levelSettings"], val: unknown) => {
    if (!config) return;
    setConfig({ ...config, levelSettings: { ...config.levelSettings, [key]: val } });
  };

  if (!config) return <div className="space-y-4">{[...Array(2)].map((_, i) => <div key={i} className="stat-card rounded-xl p-5 h-40 animate-pulse" />)}</div>;

  const lvl = config.levelSettings;
  const xpForLevel = (n: number) => Math.floor(100 * Math.pow(n, 1.5));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">Levels & XP</h2>
          <p className="text-muted-foreground text-sm mt-0.5">نظام النقاط والمستويات</p>
        </div>
        <button onClick={save} disabled={saving} className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium text-sm transition-colors disabled:opacity-50">
          <Save className="w-4 h-4" />
          {saving ? "جاري الحفظ…" : "حفظ التغييرات"}
        </button>
      </div>

      <div className="stat-card rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-2"><Star className="w-4 h-4 text-purple-400" /><h3 className="font-semibold text-white">إعدادات XP</h3></div>
        <Toggle label="تفعيل نظام XP" desc="الأعضاء يكسبون XP بإرسال الرسائل" value={lvl.enabled} onChange={(v) => setL("enabled", v)} />
        <Row label="XP لكل رسالة" desc="النقاط الممنوحة لكل رسالة">
          <input type="number" min={1} max={500} className="w-28 px-3 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white focus:outline-none focus:ring-1 focus:ring-purple-500" value={lvl.xpPerMessage} onChange={(e) => setL("xpPerMessage", Number(e.target.value))} />
        </Row>
        <Row label="فترة الانتظار (ms)" desc="وقت الانتظار بين كسب النقاط">
          <input type="number" min={1000} max={300000} step={1000} className="w-28 px-3 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white focus:outline-none focus:ring-1 focus:ring-purple-500" value={lvl.xpCooldown} onChange={(e) => setL("xpCooldown", Number(e.target.value))} />
        </Row>
        <Row label="قناة الإعلان" desc="القناة لإعلانات Level Up">
          <input className="w-36 px-3 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-purple-500" value={lvl.announceChannel || ""} onChange={(e) => setL("announceChannel", e.target.value || null)} placeholder="123456789" />
        </Row>
      </div>

      {/* XP table */}
      <div className="stat-card rounded-xl p-5">
        <h3 className="font-semibold text-white mb-3">جدول المستويات (XP المطلوب)</h3>
        <div className="grid grid-cols-5 gap-2">
          {[1,2,3,4,5,10,15,20,25,50].map((n) => (
            <div key={n} className="text-center p-2 rounded-lg bg-muted/30">
              <div className="text-xs font-bold text-purple-300">Lvl {n}</div>
              <div className="text-xs text-muted-foreground">{xpForLevel(n).toLocaleString()}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Leaderboard */}
      <div className="stat-card rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Trophy className="w-4 h-4 text-yellow-400" />
          <h3 className="font-semibold text-white">Leaderboard</h3>
          <span className="text-xs text-muted-foreground ml-auto">{leaderboard.length} عضو</span>
        </div>
        {leaderboard.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground">
            <Trophy className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p className="text-sm">لا يوجد أعضاء في اللوحة بعد</p>
            <p className="text-xs mt-1">فعّل نظام XP وسيظهر الأعضاء هنا</p>
          </div>
        ) : (
          <div className="space-y-2">
            {leaderboard.map((u, i) => (
              <div key={u.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/20">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${i === 0 ? "bg-yellow-500 text-black" : i === 1 ? "bg-gray-300 text-black" : i === 2 ? "bg-orange-600 text-white" : "bg-muted text-muted-foreground"}`}>{i + 1}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-white truncate">…{u.id.slice(-6)}</span>
                    <span className="text-xs text-muted-foreground ml-2">{u.xp.toLocaleString()} XP</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5">
                    <div className="bg-gradient-to-r from-purple-500 to-blue-500 h-1.5 rounded-full" style={{ width: `${Math.min(100, (u.xp / (leaderboard[0]?.xp || 1)) * 100)}%` }} />
                  </div>
                </div>
                <div className="text-sm font-bold text-purple-300 flex-shrink-0">Lvl {u.level}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Toggle({ label, desc, value, onChange }: { label: string; desc: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div><div className="text-sm font-medium text-white">{label}</div><div className="text-xs text-muted-foreground mt-0.5">{desc}</div></div>
      <button onClick={() => onChange(!value)} className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${value ? "bg-purple-600" : "bg-muted"}`}>
        <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${value ? "left-6" : "left-1"}`} />
      </button>
    </div>
  );
}
function Row({ label, desc, children }: { label: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 flex-wrap">
      <div className="flex-1"><div className="text-sm font-medium text-white">{label}</div><div className="text-xs text-muted-foreground mt-0.5">{desc}</div></div>
      {children}
    </div>
  );
}
