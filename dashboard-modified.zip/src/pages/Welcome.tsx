import { useEffect, useState } from "react";
import { api, BotConfig } from "@/lib/api";
import { LogIn, LogOut, Save, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { GuildHeader, ChannelSelect } from "@/components/DiscordSelect";
import { useGuilds } from "@/hooks/useDiscord";

export default function Welcome() {
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [saving, setSaving] = useState(false);
  const [guildId, setGuildId] = useState("");
  const { guilds } = useGuilds();
  const { toast } = useToast();

  useEffect(() => { api.getConfig().then(setConfig).catch(() => {}); }, []);

  useEffect(() => {
    if (guilds.length === 1 && !guildId) setGuildId(guilds[0].id);
  }, [guilds]);

  const save = async () => {
    if (!config) return;
    setSaving(true);
    try {
      await api.updateConfig({
        welcomeChannel: config.welcomeChannel,
        welcomeMessage: config.welcomeMessage,
        leaveChannel: config.leaveChannel,
        leaveMessage: config.leaveMessage,
        levelSettings: config.levelSettings,
      });
      toast({ title: "✅ تم الحفظ", description: "تم تحديث رسائل الترحيب والوداع." });
    } catch {
      toast({ title: "خطأ", description: "فشل في الحفظ.", variant: "destructive" });
    } finally { setSaving(false); }
  };

  if (!config) return <div className="space-y-4">{[...Array(3)].map((_, i) => <div key={i} className="stat-card rounded-xl p-5 h-44 animate-pulse" />)}</div>;

  const previewMsg = (msg: string) =>
    msg.replace("{user}", "@أحمد").replace("{username}", "أحمد").replace("{server}", "سيرفري").replace("{count}", "1,234");

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">الترحيب والوداع</h2>
          <p className="text-muted-foreground text-sm mt-0.5">رسائل الترحيب بالأعضاء الجدد والوداع</p>
        </div>
        <button onClick={save} disabled={saving} className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium text-sm transition-colors disabled:opacity-50">
          <Save className="w-4 h-4" />
          {saving ? "جاري الحفظ…" : "حفظ التغييرات"}
        </button>
      </div>

      <GuildHeader guildId={guildId} onGuildChange={setGuildId} />

      <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
        <h4 className="text-sm font-semibold text-blue-300 mb-2">📝 متغيرات الرسالة</h4>
        <div className="grid grid-cols-2 gap-2 text-xs">
          {[["{user}", "تاغ العضو"], ["{username}", "اسم العضو"], ["{server}", "اسم السيرفر"], ["{count}", "عدد الأعضاء"]].map(([v, d]) => (
            <div key={v} className="flex gap-2"><code className="text-purple-300 font-mono">{v}</code><span className="text-muted-foreground">— {d}</span></div>
          ))}
        </div>
      </div>

      <div className="stat-card rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-2"><LogIn className="w-4 h-4 text-green-400" /><h3 className="font-semibold text-white">رسالة الترحيب</h3></div>
        <Row label="قناة الترحيب">
          <ChannelSelect
            guildId={guildId}
            value={config.welcomeChannel || ""}
            onChange={(v) => setConfig({ ...config, welcomeChannel: v || null })}
            types={[0]}
            placeholder="— اختر قناة نصية —"
          />
        </Row>
        <div>
          <label className="text-sm font-medium text-white block mb-1">نص الرسالة</label>
          <textarea className="w-full px-3 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-purple-500 resize-none" rows={3} value={config.welcomeMessage} onChange={(e) => setConfig({ ...config, welcomeMessage: e.target.value })} />
        </div>
        <Preview msg={previewMsg(config.welcomeMessage)} />
      </div>

      <div className="stat-card rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-2"><LogOut className="w-4 h-4 text-red-400" /><h3 className="font-semibold text-white">رسالة الوداع</h3></div>
        <Row label="قناة الوداع">
          <ChannelSelect
            guildId={guildId}
            value={config.leaveChannel || ""}
            onChange={(v) => setConfig({ ...config, leaveChannel: v || null })}
            types={[0]}
            placeholder="— اختر قناة نصية —"
          />
        </Row>
        <div>
          <label className="text-sm font-medium text-white block mb-1">نص الرسالة</label>
          <textarea className="w-full px-3 py-2 bg-muted/50 border border-border rounded-lg text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-purple-500 resize-none" rows={3} value={config.leaveMessage} onChange={(e) => setConfig({ ...config, leaveMessage: e.target.value })} />
        </div>
        <Preview msg={previewMsg(config.leaveMessage)} />
      </div>

      <div className="stat-card rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-2"><Star className="w-4 h-4 text-yellow-400" /><h3 className="font-semibold text-white">رسالة Level Up</h3></div>
        <Row label="قناة الإعلان">
          <ChannelSelect
            guildId={guildId}
            value={config.levelSettings.announceChannel || ""}
            onChange={(v) => setConfig({ ...config, levelSettings: { ...config.levelSettings, announceChannel: v || null } })}
            types={[0]}
            placeholder="— اختر قناة —"
          />
        </Row>
      </div>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 flex-wrap">
      <label className="text-sm font-medium text-white">{label}</label>
      <div className="w-full sm:w-56">{children}</div>
    </div>
  );
}

function Preview({ msg }: { msg: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground mb-2">معاينة:</p>
      <div className="p-3 rounded-lg bg-[#2b2d31] border border-[#1e1f22] flex items-start gap-2">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex-shrink-0" />
        <div><span className="text-xs font-semibold text-purple-300">RXZ Bot</span><p className="text-sm text-gray-200 mt-0.5">{msg}</p></div>
      </div>
    </div>
  );
}
