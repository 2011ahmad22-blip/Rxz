const API_BASE = "/api/bot";
const API_KEY = "rxz-dashboard-key";

const headers = {
  "Content-Type": "application/json",
  "x-api-key": API_KEY,
};

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { ...headers, ...(options?.headers || {}) },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

export type BotStats = {
  totalWarnings: number; totalMuted: number; totalXpUsers: number;
  activeGiveaways: number; customCmds: number; aliases: number; prefix: string;
};

export type ProtectionSettings = {
  antiBot: boolean; antiSpam: boolean; antiLink: boolean;
  antiSwear: boolean; antiCaps: boolean; antiMentionSpam: boolean; antiRaid: boolean;
  spamThreshold: number; spamInterval: number; capsPercent: number;
  mentionLimit: number; raidThreshold: number; raidInterval: number; swearWords: string[];
};

export type WarnPunishment = { count: number; action: string; duration?: number };

export type LevelSettings = {
  enabled: boolean; xpPerMessage: number; xpCooldown: number;
  announceChannel: string | null; levelRoles: Record<number, string>;
};

export type TicketSettings = {
  enabled: boolean;
  categoryId: string | null;
  supportRoles: string[];
  logChannel: string | null;
  transcriptChannel: string | null;
  openMessage: string;
  panelTitle: string;
  panelDescription: string;
  panelColor: string;
  buttonLabel: string;
  buttonEmoji: string;
  buttonColor: "Primary" | "Secondary" | "Success" | "Danger";
  maxTicketsPerUser: number;
  reasonRequired: boolean;
  closeReasonRequired: boolean;
  pingSupport: boolean;
  closeConfirmation: boolean;
  dmOnClose: boolean;
  transcriptOnClose: boolean;
  autoClose: boolean;
  autoCloseHours: number;
  ratingEnabled: boolean;
  ratingChannel: string | null;
  ticketNameFormat: string;
  claimEnabled: boolean;
  claimRole: string | null;
};

export type BotConfig = {
  prefix: string;
  welcomeChannel: string | null; welcomeMessage: string;
  leaveChannel: string | null; leaveMessage: string;
  muteRole: string | null; modRoles: string[]; logsChannel: string | null; autoRoles: string[];
  protection: ProtectionSettings;
  autoMod: { deleteWarning: boolean; warnOnViolation: boolean; muteOnRepeatViolation: boolean };
  warnPunishments: WarnPunishment[];
  levelSettings: LevelSettings;
  ticketSettings: TicketSettings;
  customCommands: { trigger: string; response: string }[];
  commandAliases: Record<string, string>;
  raidLocked: boolean;
};

export type DiscordGuild = { id: string; name: string; icon: string | null; memberCount: number };
export type DiscordChannel = { id: string; name: string; type: number };
export type DiscordRole = { id: string; name: string; color: string; position: number };

export type BotStatus = {
  hasToken: boolean; hasClientId: boolean; online: boolean;
  botName: string | null; botAvatar: string | null; guilds: number;
};

export const api = {
  getStatus: () => apiFetch<BotStatus>("/status"),
  getConfig: () => apiFetch<BotConfig>("/config"),
  updateConfig: (data: Partial<BotConfig>) =>
    apiFetch("/config", { method: "PUT", body: JSON.stringify(data) }),
  getStats: () => apiFetch<BotStats>("/stats"),
  getWarnings: () =>
    apiFetch<Record<string, Array<{ reason: string; by: string; at: number }>>>("/warnings"),
  deleteWarnings: (userId: string) =>
    apiFetch(`/warnings/${userId}`, { method: "DELETE" }),
  getGiveaways: () =>
    apiFetch<Array<{
      id: string; channelId: string; messageId: string; prize: string; endsAt: number;
      winnersCount: number; hostId: string; ended: boolean; participants: string[];
    }>>("/giveaways"),
  getCustomCommands: () =>
    apiFetch<Array<{ trigger: string; response: string }>>("/customcmds"),
  deleteCustomCommand: (trigger: string) =>
    apiFetch(`/customcmds/${encodeURIComponent(trigger)}`, { method: "DELETE" }),
  getLeaderboard: () =>
    apiFetch<Array<{ id: string; xp: number; level: number }>>("/leaderboard"),
  getGuilds: () => apiFetch<DiscordGuild[]>("/guilds"),
  getChannels: (guildId: string) => apiFetch<DiscordChannel[]>(`/guilds/${guildId}/channels`),
  getRoles: (guildId: string) => apiFetch<DiscordRole[]>(`/guilds/${guildId}/roles`),
  updateToken: (token: string) =>
    apiFetch<{ success: boolean; message: string }>("/token", { method: "POST", body: JSON.stringify({ token }) }),
};
