import { useEffect, useState } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/Sidebar";
import Overview from "@/pages/Overview";
import Moderation from "@/pages/Moderation";
import Protection from "@/pages/Protection";
import Welcome from "@/pages/Welcome";
import Levels from "@/pages/Levels";
import Giveaways from "@/pages/Giveaways";
import CustomCommands from "@/pages/CustomCommands";
import Aliases from "@/pages/Aliases";
import Settings from "@/pages/Settings";
import Tickets from "@/pages/Tickets";
import Commands from "@/pages/Commands";
import { api } from "@/lib/api";
import { Menu } from "lucide-react";

const queryClient = new QueryClient();

function Layout() {
  const [stats, setStats] = useState<{ totalWarnings: number; totalMuted: number } | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    api.getStats().then(setStats).catch(() => {});
  }, []);

  return (
    <div className="flex min-h-screen bg-background" dir="rtl">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar — right side in RTL */}
      <div className={`
        fixed lg:sticky top-0 z-30 h-screen transition-transform duration-200 right-0
        ${sidebarOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"}
      `}>
        <Sidebar
          totalWarnings={stats?.totalWarnings}
          totalMuted={stats?.totalMuted}
          onClose={() => setSidebarOpen(false)}
        />
      </div>

      {/* Main content */}
      <main className="flex-1 min-w-0 overflow-auto">
        {/* Top bar for mobile */}
        <div className="lg:hidden flex items-center gap-3 px-4 py-3 border-b border-border sticky top-0 bg-background z-10">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-white transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
              <span className="text-white text-xs font-bold">R</span>
            </div>
            <span className="font-semibold text-white text-sm">لوحة تحكم RXZ Bot</span>
          </div>
        </div>

        <div className="p-4 lg:p-6 w-full">
          <Switch>
            <Route path="/" component={Overview} />
            <Route path="/moderation" component={Moderation} />
            <Route path="/protection" component={Protection} />
            <Route path="/welcome" component={Welcome} />
            <Route path="/levels" component={Levels} />
            <Route path="/giveaways" component={Giveaways} />
            <Route path="/custom-commands" component={CustomCommands} />
            <Route path="/aliases" component={Aliases} />
            <Route path="/tickets" component={Tickets} />
            <Route path="/commands" component={Commands} />
            <Route path="/settings" component={Settings} />
            <Route>
              <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
                <div className="text-6xl mb-4">🤖</div>
                <h2 className="text-2xl font-bold text-white mb-2">الصفحة غير موجودة</h2>
                <p className="text-muted-foreground">هذه الصفحة غير متوفرة.</p>
              </div>
            </Route>
          </Switch>
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Layout />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
